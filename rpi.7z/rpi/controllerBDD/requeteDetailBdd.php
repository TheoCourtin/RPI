<?php
//header('contant-type : text/html; charset=utf-8');

$idBdd = $_GET['bdd']; //vérifier si la variable est correct (int non vide)
// echo json_encode();
//var_dump($_GET['serveur']);

//connexion à la base de donnée
$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';

//requête sql
$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("SELECT B.*,CONCAT(S.nom, ' - ', S.ip) AS infoServeur from bdd B left join serveur S on S.idServeur = B.idServeur where B.idBdd=$idBdd");
$sth->execute();
$resultBdd = $sth->fetchAll();
//var_dump($result);

//On définie des variables globales
foreach ($resultBdd as $key=>$value) {
	$nomBdd = $value['nom'];
	$ipBdd = $value['ip'];
	$accesBdd = $value['typeAcces'];
	$compteBdd = $value['typeCompte'];
  $infoServeur = $value['infoServeur'];
  $idServeur = $value['idServeur'];

	if ($value['test']==1)
		{$test = 'Yes';}
	else{
		$test = 'No';}
}

//serveur de la bdd
$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("select idServeur,CONCAT(nom, ' - ', ip) AS infoServeur from serveur order by nom");
$sth->execute();
$resultBdd = $sth->fetchAll();

$listServeur = $resultBdd;
