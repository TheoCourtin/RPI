<?php
//header('contant-type : text/html; charset=utf-8');

$idBdd = $_GET['bdd']; //vérifier si la variable est correct (int non vide)
//echo json_encode();

//connexion à la base de donnée
$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';

//requête sql
$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare('UPDATE bdd SET nom = :nom, ip = :ip, typeAcces = :typeAcces, typeCompte = :typeCompte, test = :test, infoServeur = :infoServeur where idBdd = :id');
$resultProjet = $sth->execute(array(
  ':id' => $idBdd,
  ':nom'=> $_POST['nom'],
  ':ip'=> $_POST['ip'],
  ':typeAcces' => $_POST["acces"],
  ':typeCompte' => $_POST['compte'],
  ':test' => $_POST['test'],
  ':infoServeur' => $_POST['serveur']
));

header("location:../view/uneBdd.php?bdd=$idBdd");
exit();
?>
