<?php
// header('contant-type : text/html; charset=utf-8');

$idBdd = $_GET['bdd']; //vérifier si la variable est correct (int non vide)
// echo json_encode();

$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("SELECT * from projet where idBdd=$idBdd");
$sth->execute();
$resultBdd = $sth->fetchAll();

foreach ($resultBdd as $key=>$value) {
	 	$idProjet = $value['idProjet'];
		echo "<td align='center'><a href='Unprojet.php?projet=$idProjet' target='_blank'>".$value['nomProjet']."</a></td>";
		echo "<td align='center'>".$value['statut']."</tr>";
}
