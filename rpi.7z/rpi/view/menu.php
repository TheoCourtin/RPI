<?php
require_once('../controller/traduction.php');
$espace="&nbsp";
?>
<!--Première Navbar-->
<nav class ="navbar navbar-top" id="navbar">
	<a class="navbar-brand" href="accueil.php">
		<img class="pull-left" style="height: 25px;" src="../img/atos.png" alt="AtoS - ISM">
	</a>
    <a href="listeProjets.php">
	    <span class="navBoutonHaut navbar-brand">
		    <b><font color="white">
		    <?php echo $langue == "fr" ? projetsFR : projetsEN; ?>
		    </font></b>
		</span>
	</a>
	<a href="listeServeurs.php">
	    <span class="navBoutonHaut navbar-brand">
		    <b><font color="white">
		    <?php echo $langue == "fr" ? serveursFR : serveursEN; ?>
		    </font></b>
		</span>
	</a>
	<a href="listeBdd.php">
	    <span class="navBoutonHaut navbar-brand">
		    <b><font color="white">
		    <?php echo $langue == "fr" ? bddFR : bddEN; ?>
		    </font></b>
		</span>
	</a>
	<a href="listeContacts.php">
	    <span class="navBoutonHaut navbar-brand">
		    <b><font color="white">
		    <?php echo $langue == "fr" ? contactsFR : contactsEN; ?>
		    </font></b>
		</span>
	</a>
	<a class="nav-link" href="../logout.php">
		<span class="navbar-right navBoutonHaut navbar-brand" style="margin: 0px 10px;">
		    <span class="glyphicon glyphicon-new-window" style="color: white; font-size: 16px;top: 3px;"></span>
		    <font size="+1" color="white"><b>&nbsp;<?php
		    echo $langue == "fr" ? deconnexionFR : deconnexionEN;
		    ?></b></font>
	    </span>
	</a>
	<div class="btn-group pull-right">
	    <form method="POST" name="langues" class="navbar-form navbar-right" id="form_langue">
		    <!--Sélection langue-->
		    <select name="langue"  class="form-control btn dropdown-toggle" action="accueil.php" onChange="document.getElementById('form_langue').submit();">
			    <?php
				    echo "<option value = 'en' ".($langue == 'en' ? 'selected' : '')."> English </option>";
				    echo "<option value = 'fr' ".($langue == 'fr' ? 'selected' : '')."> Français </option>";
			    ?>
		    </select>
		</form>
	</div>
	<form class="navbar-form navbar-right">
		<!--Barre de recherche-->
		<div class="input-group">
			<input type="text" class="form-control" style="heigth: 10px" placeholder=<?php echo $langue == "fr" ? rechercherFR : rechercherEN;?> aria-label="Search">
			<span class="input-group-btn">
			<button type="button" class="btn btn-default"><span class="glyphicon glyphicon-search"></span></button>
		</div>
	</form>
</nav>
<!--fin première Navbar-->
<!--Seconde Navbar-->
<nav class="navbar2 navbar-top" id="navbar2">
        <?php $path=$_SERVER['PHP_SELF']; $filename = pathinfo($path, PATHINFO_FILENAME);

			switch ($filename) {
				//Accueil

				case 'accueil' : ?>
				    <span class="navBoutonBasCurrent">
	    		        <b><font color="white">
						    <?php echo $langue == "fr" ? accueilFR : accueilEN; ?>
	    		        </font></b>
			        </span>
    				<?php
				break;
				//Liste projet
				case 'listeProjets' : ?>
				    <a href="accueil.php">
						<span class="navBoutonBas">
						    <b><font color="white">
						    <?php echo $langue == "fr" ? accueilFR : accueilEN; ?>
						    </font></b>
						</span>
					</a>
				    <span class="navBoutonBasCurrent">
	    		        <b><font color="white">
	    		        <?php echo $langue == "fr" ? projetsFR : projetsEN; ?>
	    		        </font></b>
			        </span>
    				<?php
				break;
				//Fiche projet
				case 'Unprojet' : ?>
				    <a href="accueil.php">
						<span class="navBoutonBas">
						    <b><font color="white">
						    <?php echo $langue == "fr" ? accueilFR : accueilEN; ?>
						    </font></b>
						</span>
					</a>
					<a href="listeProjets.php">
					    <span class="navBoutonBas">
		    		        <b><font color="white">
		    		        <?php echo $langue == "fr" ? projetsFR : projetsEN; ?>
		    		        </font></b>
				        </span>
					</a>
				    <span class="navBoutonBasCurrent">
					    <b><font color="white">
		    		    <?php echo $nomProjet; ?>
		    		    </font></b>
					</span>
					<?php
					break;
				//Editer projet
				case 'editProjet' : ?>
				    <a href="accueil.php">
						<span class="navBoutonBas">
						    <b><font color="white">
						    <?php echo $langue == "fr" ? accueilFR : accueilEN; ?>
						    </font></b>
						</span>
					</a>
					<a href="listeProjets.php">
					    <span class="navBoutonBas">
		    		        <b><font color="white">
		    		        <?php echo $langue == "fr" ? projetsFR : projetsEN; ?>
		    		        </font></b>
				        </span>
					</a>
					<?php echo"<a href='Unprojet.php?projet=".$idProj."'>"; ?>
				        <span class="navBoutonBas">
					        <b><font color="white">
		    		        <?php echo $nomProjet; ?>
		    		        </font></b>
					    </span>
					</a>
					<span class="navBoutonBasCurrent">
					    <b><font color="white">
		    		    <?php echo $langue == "fr" ? editerboutonFR : editerboutonEN; ?>
		    		    </font></b>
					</span>
					<?php
					break;
				//Liste serveur
				case 'listeServeurs' : ?>
				    <a href="accueil.php">
						<span class="navBoutonBas">
						    <b><font color="white">
						    <?php echo $langue == "fr" ? accueilFR : accueilEN; ?>
						    </font></b>
						</span>
					</a>
				    <span class="navBoutonBasCurrent">
	    		        <b><font color="white">
	    		        <?php echo $langue == "fr" ? serveursFR : serveursEN; ?>
	    		        </font></b>
			        </span>
					<?php
				    break;
				//Fiche serveur
				case 'unServeur' : ?>
				    <a href="accueil.php">
						<span class="navBoutonBas">
						    <b><font color="white">
						    <?php echo $langue == "fr" ? accueilFR : accueilEN; ?>
						    </font></b>
						</span>
					</a>
					<a href="listeServeurs.php">
					    <span class="navBoutonBas">
		    		        <b><font color="white">
		    		        <?php echo $langue == "fr" ? serveursFR : serveursEN; ?>
		    		        </font></b>
				        </span>
					</a>
				    <span class="navBoutonBasCurrent">
					    <b><font color="white">
		    		    <?php echo $nom; ?>
		    		    </font></b>
					</span>
					<?php
				    break;
				//Editer server
				case 'editServeur' : ?>
				    <a href="accueil.php">
						<span class="navBoutonBas">
						    <b><font color="white">
						    <?php echo $langue == "fr" ? accueilFR : accueilEN; ?>
						    </font></b>
						</span>
					</a>
					<a href="listeServeurs.php">
					    <span class="navBoutonBas">
		    		        <b><font color="white">
		    		        <?php echo $langue == "fr" ? serveursFR : serveursEN; ?>
		    		        </font></b>
				        </span>
					</a>
					<?php echo"<a href='unServeur.php?serveur=".$idServeur."'>"; ?>
				        <span class="navBoutonBas">
					        <b><font color="white">
		    		        <?php echo $nom; ?>
		    		        </font></b>
					    </span>
					</a>
					<span class="navBoutonBasCurrent">
					    <b><font color="white">
		    		    <?php echo $langue == "fr" ? editerboutonFR : editerboutonEN; ?>
		    		    </font></b>
					</span>
					<?php
				    break;
				//Liste base de données
				case 'listeBdd' : ?>
				    <a href="accueil.php">
						<span class="navBoutonBas">
						    <b><font color="white">
						    <?php echo $langue == "fr" ? accueilFR : accueilEN; ?>
						    </font></b>
						</span>
					</a>
				    <span class="navBoutonBasCurrent">
	    		        <b><font color="white">
	    		        <?php echo $langue == "fr" ? bddFR : bddEN; ?>
	    		        </font></b>
			        </span>
					<?php
                    break;
                //Fiche base de données
                case 'uneBdd' : ?>
				    <a href="accueil.php">
						<span class="navBoutonBas">
						    <b><font color="white">
						    <?php echo $langue == "fr" ? accueilFR : accueilEN; ?>
						    </font></b>
						</span>
					</a>
					<a href="listeBdd.php">
					    <span class="navBoutonBas">
		    		        <b><font color="white">
		    		        <?php echo $langue == "fr" ? bddFR : bddEN; ?>
		    		        </font></b>
				        </span>
					</a>
				    <span class="navBoutonBasCurrent">
					    <b><font color="white">
		    		    <?php echo $nomBdd; ?>
		    		    </font></b>
					</span>
					<?php
                    break;
				//Editer base de données
				case 'editBdd' : ?>
				    <a href="accueil.php">
						<span class="navBoutonBas">
						    <b><font color="white">
						    <?php echo $langue == "fr" ? accueilFR : accueilEN; ?>
						    </font></b>
						</span>
					</a>
					<a href="listeBdd.php">
					    <span class="navBoutonBas">
		    		        <b><font color="white">
		    		        <?php echo $langue == "fr" ? bddFR : bddEN; ?>
		    		        </font></b>
				        </span>
					</a>
					<?php echo"<a href='uneBdd.php?bdd=".$idBdd."'>"; ?>
				        <span class="navBoutonBas">
					        <b><font color="white">
		    		        <?php echo $value['nom']; ?>
		    		        </font></b>
					    </span>
					</a>
				    <span class="navBoutonBasCurrent">
					    <b><font color="white">
		    		    <?php echo $langue == "fr" ? editerboutonFR : editerboutonEN; ?>
		    		    </font></b>
					</span>
					<?php
                    break;
				//Liste contact
				case 'listeContacts' : ?>
				    <a href="accueil.php">
						<span class="navBoutonBas">
						    <b><font color="white">
						    <?php echo $langue == "fr" ? accueilFR : accueilEN; ?>
						    </font></b>
						</span>
					</a>
				    <span class="navBoutonBasCurrent">
	    		        <b><font color="white">
	    		        <?php echo $langue == "fr" ? contactsFR : contactsEN; ?>
	    		        </font></b>
			        </span>
					<?php
                    break;
                //Fiche contact
                case 'unContact' : ?>
				    <a href="accueil.php">
						<span class="navBoutonBas">
						    <b><font color="white">
						    <?php echo $langue == "fr" ? accueilFR : accueilEN; ?>
						    </font></b>
						</span>
					</a>
					<a href="listeContacts.php">
					    <span class="navBoutonBas">
		    		        <b><font color="white">
		    		        <?php echo $langue == "fr" ? contactsFR : contactsEN; ?>
		    		        </font></b>
				        </span>
					</a>
				    <span class="navBoutonBasCurrent">
					    <b><font color="white">
		    		    <?php echo $GET['nom'].$espace.$GET['prenom']; ?>
		    		    </font></b>
					</span>
					<?php
                    break;
				//Editer contact
				case 'editContact' : ?>
				    <a href="accueil.php">
						<span class="navBoutonBas">
						    <b><font color="white">
						    <?php echo $langue == "fr" ? accueilFR : accueilEN; ?>
						    </font></b>
						</span>
					</a>
					<a href="listeContacts.php">
					    <span class="navBoutonBas">
		    		        <b><font color="white">
		    		        <?php echo $langue == "fr" ? contactsFR : contactsEN; ?>
		    		        </font></b>
				        </span>
					</a>
					<?php echo"<a href='unContact.php?contact=".$idContact."'>"; ?>
				        <span class="navBoutonBas">
					        <b><font color="white">
		    		        <?php echo $GET['nom'].$espace.$GET['prenom']; ?>
		    		        </font></b>
					    </span>
					</a>
				    <span class="navBoutonBasCurrent">
					    <b><font color="white">
		    		    <?php echo $langue == "fr" ? editerboutonFR : editerboutonEN; ?>
		    		    </font></b>
					</span>
					<?php
                    break;
			}
		?>
</nav>
<!--Fin Seconde Navbar-->

<link rel="icon" type="image/png" href="../img/logo_unity.png"/>
<link rel="shortcut icon" href="../img/logo_unity.ico">
