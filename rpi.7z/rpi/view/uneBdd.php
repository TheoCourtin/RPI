<?php require_once('../controller/traduction.php'); ?>
<!DOCTYPE html>

<!-- encodage utf-8-->
<meta http-equiv="content-type" content="text/html" charset="utf-8">
<!-- Extension jQuery-->
<script type='text/javascript' src='../extension/jquery-3.3.1.min.js'></script>
<!--Extension Bootstrap--->
<link rel="stylesheet" href="../extension/bootstrap/css/bootstrap.min.css"/>
<script src="../extension/bootstrap/js/bootstrap.min.js"></script>
<!--Ajout CSS-->
<link rel="stylesheet" href="css/default.css"/>

<?php $idBdd=$_GET['bdd'];
include("../controllerBDD/requeteDetailBdd.php");?>



<head>
  <title>

    <?php echo $langue == "fr" ? detailbddFR : detailbddEN; ?>
  </title>

  <!--Navbar fixé en haut-->
  <?php include('menu.php');?></nav>


  <h1 class="text-center">
    <div class="encadrement cadre">
      <font color="white"><?php echo strtoupper($nomBdd);?></font>
    </div>
  </br>
</h1>

<div class="espace pull-right">
<?php	$trad =$langue == "fr" ? editerboutonFR : editerboutonEN;
   echo "<a href ='editBdd.php?bdd=$idBdd' class='btn btn-md btn-danger'>".$trad."</a>"; ?>
</div>

</head>

<body>
  <?php include("../controllerBDD/requeteDetailBdd.php"); ?>
  <div class="container" style="padding:75px;">
    <div class="panel panel-default">
          <div class="panel-heading text-center"><strong><h4><?php echo $langue == "fr" ? detailsFR : detailsEN; ?></h4></strong></div>
          <div class="panel-body">
            <div class ="block pull-left" style="padding-left:75px;">
              <strong><?php echo $langue == "fr" ? adresseIpFR : adresseIpEN; ?></strong> : <?php echo $ipBdd; ?></br>
              <strong><?php echo $langue == "fr" ? typeAccesFR : typeAccesEN; ?></strong> : <?php echo $accesBdd; ?></br>
              <strong><?php echo $langue == "fr" ? typecompteFR : typecompteFR; ?></strong> : <?php echo $compteBdd; ?></br>
            </div>

            <div class="block pull-right" style="padding-right:75px">
              <strong><?php echo $langue == "fr" ? serveurtestFR : serveurtestEN; ?></strong> : <?php echo $test; ?></br>
              <?php $idServeur = $value['idServeur']; ?>
              <strong><?php echo $langue == "fr" ? serveurFR : serveurEN; ?> </u></strong> : <?php echo "<a href='unServeur.php?serveur=$idServeur'>".$infoServeur."</a>"; ?></th>
            </div>
          </div>
        </div>

        <table class="table table-bordered table-hover">
          <thead>
            <h4 class="text-center"><b> &nbsp;<?php echo $langue == "fr" ? projetsFR : projetsEN; ?> </b> </h4> </br>
            <tr>
              <th class="text-center" bgcolor="#BCCCE1"><?php echo $langue == "fr" ? projectnomFR : projectnomEN; ?></font></th>
              <th class="text-center" bgcolor="#BCCCE1"><?php echo $langue == "fr" ? statutFR : statutEN; ?></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <?php
                include('../controllerBDD/tableaubddprojet.php');?>
              </tr>
            </tbody>
          </table>
        </div>

        <div class="col-xs-11 pull-right">
          <a href="listeBdd.php" class="btn btn-primary btn-md"><?php echo $langue == "fr" ? retourFR : retourEN; ?></button></a>
        </div>
      </body>
    </html>
