<?php require_once('../controller/traduction.php'); ?>
<!DOCTYPE html>

<!-- encodage utf-8-->
<meta http-equiv="content-type" content="text/html" charset="utf-8">
<!-- Extension jQuery-->
<script type='text/javascript' src='../extension/jquery-3.3.1.min.js'></script>
<!--Extension Bootstrap--->
<link rel="stylesheet" href="../extension/bootstrap/css/bootstrap.min.css"/>
<script src="../extension/bootstrap/js/bootstrap.min.js"></script>
<!--Ajout CSS-->
<link rel="stylesheet" href="css/default.css"/>
<?php
$idBdd = $_GET['bdd'];
include("../controllerBDD/requeteDetailBdd.php");?>


<head>

  <title>
    <?php echo $langue == "fr" ? detailbddFR : detailbddEN; ?>
  </title>

  <!--Navbar fixé en haut-->
  <?php include('menu.php');?>

  <div class="container">
    <h1 class="text-center">
      <u><?php echo $langue == "fr"? editerboutonFR : editerboutonEN; ?></u>
    </h1>
  </br>
	</div>
</head>

<body>
  <body>

    <div class=container>
      <div class="panel panel-default">
        <div class="panel-heading"><p class="text-center"><strong><?php echo $langue == "fr" ? detailsFR : detailsEN; ?></strong></p></div>
        <div class="panel-body">
          <?php $idBdd = $_GET['bdd']; ?>
          <form method="post" action="../controllerBDD/editionBdd.php?bdd=<?php echo $idBdd;?>">
          <div class="block pull-left" style="padding-left:50px;">
            <strong><?php echo $langue == "fr" ? nomFR : nomEN;?></strong> <input id="inputnom" type="text" name="nom" class="form-control col-sm-4" value='<?php echo $nomBdd;?>' /></br>
            <strong><?php echo $langue == "fr" ? adresseIpFR : adresseIpEN;?></strong><input id="inputip" type="text" name="ip" class="form-control col-sm-4" value='<?php echo $ipBdd;?>' /></br>

            <strong><?php echo $langue == "fr" ? serveurFR : serveurEN;?></strong><select id="serveur" name="serveur" class="form-control col-sm-4">
            <?php
              foreach ($listServeur as $key => $serveur) {
                $idServeur = $serveur['idServeur'];
                $selected = $idServeur == $idServeur ? "selected" : "";
                echo "<option value='$idServeur' $selected>".$serveur['infoServeur']."</option>";
              }
            ?>
            </select></br>
          </div>
          <div class="block pull-right" style="padding-right:50px;">
            <strong><?php echo $langue == "fr" ? serveurtestFR : serveurtestEN;?></strong><select name="test" class="form-control form-control-sm btn dropdown-toggle text-left" action="editServeur.php">
            <?php
                if(test==1) {
                    echo "<option value = '1' selected>".($langue == "fr" ? ouiFR : ouiEN)."</option>";
                    echo "<option value = '0'>".($langue == "fr" ? nonFR : nonEN)."</option>";
                }
                else {
                    echo "<option value = '1'>".($langue == "fr" ? ouiFR : ouiEN)."</option>";
                    echo "<option value = '0' selected>".($langue == "fr" ? nonFR : nonEN)."</option>";
                }
            ?>
            </select></br>
            <strong> <?php echo $langue == "fr" ? typeAccesFR : typeAccesEN;?> </strong>: <input id="inputacces" type="text" name="acces" class="form-control col-sm-4" value='<?php echo $accesBdd; ?>' /></br>
            <strong><?php echo $langue == "fr" ? typecompteFR : typecompteEN;?></strong>: <input id="inputcompte" type="text" name="compte" class="form-control col-sm-4" value='<?php echo $compteBdd;?>' /></br>
          </div>
        </div>
      </div>

      <div class="container">
        <div class="pull-left" style="margin-left:75px;">
          <input type="submit" name="Renvoi" class="btn btn-success btn-md" value="<?php echo $langue == "fr" ? validerFR : validerEN;?>">
        </div>
        <div class="pull-right" style="margin-right:75px;">
		    <?php
		        echo "<a href='uneBdd?bdd=".$idBdd."' class='btn btn-primary btn-sm'>";
				echo $langue == "fr" ? retourFR : retourEN;
			?></a>
        </div>
      </div>
    </form>
      </body>
    </html>
