<?php require_once('../controller/traduction.php'); ?>
<!DOCTYPE html>
<html lang="en-US">

<!-- encodage utf-8-->
<meta http-equiv="content-type" content="text/html" charset="utf-8">

<!-- Extension jQuery-->
<script type='text/javascript' src='../extension/jquery-3.3.1.min.js'></script>

<!--Extension Bootstrap--->
<link rel="stylesheet" href="../extension/bootstrap/css/bootstrap.min.css"/>
<script src="../extension/bootstrap/js/bootstrap.min.js"></script>
<!--Ajout CSS-->
<link rel="stylesheet" href="css/default.css"/>
<?php include("../controllerProjet/requetedetailprojet.php"); ?>
<?php $idProj = $_GET['projet'];
$trad =$langue == "fr" ? editerboutonFR : editerboutonEN;			?>


<head>
	<?php include("../controllerProjet/requetedetailprojet.php");?>
	<title>
		<?php echo $langue == "fr" ? projectdetailFR : projectdetailEN; ?>
	</title>

	<!--Navbar fixé en haut-->
	<?php include('menu.php');?>

	<h1 class="text-center">
		<div class="encadrement cadre">
			<font color="white">
				<?php echo strtoupper($nomProjet);?>
			</font>
		</div>
	</h1>

	<div class="encadrement-client pull-left col-xs-2">
	<h4>
		<form class="form-inline">
			<strong><?php echo $langue == "fr" ? clientFR : clientEN; ?></strong>  <p class="form-control-static"><?php echo $nomClient; ?></p>
        </form>
    </h4>
    </div>

	<div class="espace pull-right">
		<?php echo "<a href ='editProjet.php?projet=$idProj' class='btn btn-md btn-danger'>".$trad."</a>"; ?>
	</div>
	</br></br></br></br>
</head>

<body>
    <?php $idBdd =$idBdd; ?>
    <?php $idServeur =$idServeur; ?>
    <form class="form-inline">
        <div name="Description" class="panel center-block panel-default">
			<div class="panel-heading text-center"> <?php echo $langue == "fr" ? descriptionFR : descriptionEN; ?> </div>
			<div class="panel-body" style="padding: 0px;">
                <textarea  class="text-justify textarea" style="height: 70px;">
			    <?php echo $description; ?>
				</textarea>
			</div>
        </div>
	    <div name="details">
            <strong><?php echo $langue == "fr" ? projetInterneFR : projetInterneEN; ?></strong> : <p class="form-control-static"><?php echo $proprieteAtos; ?> </p></br>
            <strong><?php echo $langue == "fr" ? statutFR : statutEN; ?></strong>  : <p class="form-control-static"><?php echo $statut; ?></p></br>
            <strong><?php echo $langue == "fr" ? technoUtiliseeFR : technoUtiliseeEN; ?> </strong> : <p class="form-control-static"><?php echo $technologieUtilisee; ?></p></br>
            <strong><?php echo $langue == "fr" ? tagsFR : tagsEN; ?> </strong> : <p class="form-control-static"><?php echo $tag; ?></p></br>
            <strong><?php echo $langue == "fr" ? documentationFR : documentationEN; ?></strong> :<p class="form-control-static"><?php echo $documentation; ?></p></br>
            <strong><?php echo $langue == "fr" ? dependanceFR : dependanceEN; ?> </strong>: <p class="form-control-static"><?php echo $dependance; ?></p></br>
        </div>
        <div name="planning">
            <strong><?php echo $langue == "fr" ? dateDebutFR : dateDebutEN; ?></strong>: <input id="date" size="10" value=<?php echo $dateDebut;?> disabled></br>
            <strong><?php echo $langue == "fr" ? dateFinFR : dateFinEN; ?></strong> : <input id="date" size="10" value=<?php echo $dateFin; ?> disabled></br>
            <strong><?php echo $langue == "fr" ? derniereModificationFR : derniereModificationEN; ?></strong>: <?php echo $dateModification; ?>
        </div>
        <div name="hebergement">
            <strong><?php echo $langue == "fr" ? bddFR : bddEN; ?> </strong> : <p class="form-control-static"><?php echo "<a href='uneBdd?bdd=$idBdd'>".$nomBdd." - ".$ipBdd."</a>"; ?></p></br>
            <strong><?php echo $langue == "fr" ? serveursFR : serveursEN; ?></strong> : <p class="form-control-static"><?php echo "<a href='unServeur?serveur=$idServeur'>".$nomServer." - ".$ipServer."</a>"; ?></p></br>
        </div>
        <div name="commentaire">
            <strong><?php echo $langue == "fr" ? commentaireFR : commentaireEN; ?></strong> :
			<!--border-bottom-width: 50px;-->
            <textarea class="form-control center-block text-justify"  style="line-height: 120%;  margin-top: 30px;">
		        <?php echo $commentaire; ?>
	        </textarea>
        </div>
	</form>
</body>

<div class="container">
<!--Tableau contact-->
	<table class="table table-bordered table-hover">
		<thead>
			<h4 class="text-center"><b><?php echo $langue == "fr" ? contactprojetFR : contactprojetEN; ?></b></h4> </br>
			<tr>
				<th class="text-center" bgcolor="#BCCCE1"> <?php echo $langue == "fr" ? nomFR : nomEN; ?> </th>
				<th class="text-center" bgcolor="#BCCCE1"><i class="glyphicon glyphicon-envelope"></i></th>
				<th class="text-center" bgcolor="#BCCCE1"><i class="glyphicon glyphicon-earphone"></i></th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<?php include('../controllerProjet/tableauContactProjet.php'); ?>
			</tr>
		</tbody>
	</table>
</div>

	<div class="espace pull-right">
		<a href="listeProjets.php" class="btn btn-primary btn-md"> <?php echo $langue == "fr" ? retourFR : retourEN; ?> </button></a>
	</div>
</body>
</html>
