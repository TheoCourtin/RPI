<?php require_once('../controller/traduction.php'); ?>
<!DOCTYPE html>
<html lang="en-US">

<!-- encodage utf-8-->
<meta http-equiv="content-type" content="text/html" charset="utf-8">

<!-- Extension jQuery-->
<script type='text/javascript' src='../extension/jquery-3.3.1.min.js'></script>
<!--Appel de notre ajax--->
<!--<script type='text/javascript' src="projetdetail.js"></script>-->
<!--Extension Bootstrap--->
<link rel="stylesheet" href="../extension/bootstrap/css/bootstrap.min.css"/>
<script src="../extension/bootstrap/js/bootstrap.min.js"></script>
<!--Lien vers le css-->
<link rel="stylesheet" href="css/default.css"/>


<head>
	<title>
		<?php
		echo $langue == "fr" ? ListeBddFR : listeBddEN;
		?>
	</title>

<!--Navbar fixé en haut-->
	<?php include('menu.php');?>

	<!--Titre-->
	<h1 class="text-center"><u>
		<?php echo $langue == "fr" ? ListeBddFR : listeBddEN;	?>
	</u></h1>
	</br>
	</br>
</head>


<body>
	<div class="tableaularge">
		<!--tableau affichant tous les projets de la base de données-->
		<div class="scrollBarVerticale">
			<table class="table table-bordered table-striped table-hover">
				<thead>
					<tr style="background-color: #BCCCE1">
						<th class="text-center"><?php echo $langue == "fr" ? nomFR : nomEN;?></th>
						<th class="text-center"><?php	echo $langue == "fr" ? adresseIpFR : adresseIpEN;?></th>
						<th class="text-center"><?php echo $langue == "fr" ? typeAccesFR : typecompteEN;?></th>

					</tr>
				</thead>

				<tbody>
				<?php include("../controllerBDD/tableauBdd.php"); ?>
			</tbody>

			</table>
		</div>
	</div>
	<div class="col-xs-11 text-right">
	<a href="accueil.php" class="btn btn-primary btn-sm"><?php echo $langue == "fr" ? retourFR : retourEN;?> </button></a>
</body>
</html>
