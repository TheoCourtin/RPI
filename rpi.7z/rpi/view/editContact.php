<?php require_once('../controller/traduction.php'); ?>
<!DOCTYPE html>
<html lang="en-US">

<!-- encodage utf-8-->
<meta http-equiv="content-type" content="text/html" charset="utf-8">

<!-- Extension jQuery-->
<script type='text/javascript' src='../extension/jquery-3.3.1.min.js'></script>

<!--Extension Bootstrap--->
<link rel="stylesheet" href="../extension/bootstrap/css/bootstrap.min.css"/>
<script src="../extension/bootstrap/js/bootstrap.min.js"></script>
<!--Ajout CSS-->
<link rel="stylesheet" href="css/default.css"/>
<?php $idContact = $_GET['contact'];
include("../controllerContact/detailcontact.php");
?>


<head>

	<title>
		<?php echo $langue == "fr" ? detailcontactFR : detailcontactEN; ?>
	</title>

	<!--Navbar fixé en haut-->
	<?php include('menu.php'); ?></nav>


	<div class="container">
		<h1 class="text-center">
      	<?php echo $langue =="fr" ? editerboutonFR : editerboutonEN; ?>
			</br>
		</div>
 </h3>
</div>
</head>


<body>


</br></br></br>
<div class="container">
	<div class="panel panel-default">
		<div class="panel-heading"><p class="text-center"><strong><?php echo $langue == "fr" ? detailsFR : detailsEN; ?></strong></p></div>
		<div class="panel-body">
			<form method="post" action="../controllerContact/editionContact.php?contact=<?php echo $idContact;?>">

			<div class="block pull-left" style="padding-left:50px;">
				<strong>DAS</strong><input id="inputdas" type="text" class="form-control col-sm-4" name="das" value='<?php echo $GET['das'];?>' /></br>
				<strong><?php echo $langue == "fr" ? nomFR : nomEN;?></strong><input id="inputnom" name="nom" type="text" class="form-control col-sm-4" value='<?php echo $GET['nom'] ?>' /></br>
				<strong><?php echo $langue == "fr" ? prenomFR : prenomEN;?></strong></span><input id="inputprenom" name="prenom" type="text" class="form-control col-sm-4" value='<?php echo $GET['prenom']?>' /></br>
					</div>

          <div class="block pull-right" style="padding-right:50px;">
						<strong><?php echo $langue == "fr" ? fonctionFR : fonctionEN; ?></strong><input id="inputfonction" name="fonction" type="text" class="form-control col-sm-4" value='<?php echo $GET['fonction']; ?>'/></br>
						<strong><span class="glyphicon glyphicon-envelope"></strong><input id="inputmail" name="email" type="text" class="form-control col-sm-4" value='<?php echo $GET['email']; ?>' /></br>
						<strong><span class="glyphicon glyphicon-earphone"></strong><input id="inputtelephone" name="telephone" type="text" class="form-control col-sm-4" value='<?php echo $GET['telephone']; ?>' /></br>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="pull-left" style="padding-left:75px";>

				<input type="submit" name="Renvoi" class="btn btn-success btn-md" value="<?php echo $langue == "fr" ? validerFR : validerEN; ?>">
			</div>
			<div class="pull-right" style="padding-right:75px;">
			    <?php
				    echo "<a href='unContact.php?contact=".$idContact."' class='btn btn-primary btn-sm'>";
					echo $langue == "fr" ? retourFR : retourEN;
				?></a>
					<!--<a href="accueil.php"class="btn btn-primary btn-sm"><?php echo $langue == "fr" ? retourFR : retourEN; ?></button></a>-->
				</div>
			</div>
		</form>
		</body>
	</html>
