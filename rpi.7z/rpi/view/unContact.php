<?php require_once('../controller/traduction.php'); ?>
<!DOCTYPE html>
<html lang="en-US">

<!-- encodage utf-8-->
<meta http-equiv="content-type" content="text/html" charset="utf-8">

<!-- Extension jQuery-->
<script type='text/javascript' src='../extension/jquery-3.3.1.min.js'></script>
<!--Appel de notre ajax--->
<!--<script type='text/javascript' src='../scriptForm.js'></script>--->
<!--Extension Bootstrap--->
<link rel="stylesheet" href="../extension/bootstrap/css/bootstrap.min.css"/>
<script src="../extension/bootstrap/js/bootstrap.min.js"></script>
<!--Ajout CSS-->
<link rel="stylesheet" href="css/default.css"/>


<head>
	<?php include("../controllerContact/detailcontact.php");?>
	<title>
		<?php echo $langue == "fr" ? detailcontactFR : detailcontactEN;	?>
	</title>

	<!--Navbar fixé en haut-->
	<?php include('menu.php');?>


	<h1 class="text-center">
		<div class="encadrement cadre">
			<font color="white"><?php echo strtoupper($GET['nom'].' '.$GET['prenom']);?></font>
		</div>
	</h1>

	<div class="espace pull-right">
	<?php	$trad =$langue == "fr" ? editerboutonFR : editerboutonEN;
		  $idContact=$_GET['contact'];
		 echo "<a href ='editContact.php?contact=$idContact' class='btn btn-md btn-danger'>".$trad."</a>"; ?>
	</div>

</br>
</head>


<body>
	<?php	include("../controllerContact/detailcontact.php");?>
</br>
</br>

		<div class="container" style="padding:75px;">
			<div class="panel panel-default">
						<div class="panel-heading text-center"><strong><h4><?php echo $langue == "fr" ? detailsFR : detailsEN; ?></h4></strong></div>
						<div class="panel-body">
							<div class ="block pull-left" style="padding-left:75px;">
								<strong>DAS</strong> : <input id="date" size="12" value=<?php if($GET['das']== ""){ echo "Externe";} else { echo $GET['das'];} ?> disabled></br>
								<strong><?php echo $langue == "fr" ? fonctionFR : fonctionEN;?></strong> : <?php echo $GET['fonction']; ?></br>
							</div>
							<div class="block pull-right" style="padding-right:75px;">
								<strong> <i class="glyphicon glyphicon-envelope"></i> </strong> : <?php echo $GET['email']; ?></br>
								<strong> <i class="glyphicon glyphicon-earphone"></i> </strong> : <?php echo $GET['telephone']; ?></br>
							</div>
						</div>
					</div>

				<table class="table table-bordered table-hover">
					<thead>
						<h4 class="text-center"><b>
							&nbsp; <?php echo $langue == "fr" ? listeProjetsFR : listeProjetsEN	?>
						</b></h4>
						</br>
						<tr>
							<th class="text-center" bgcolor="#BCCCE1"><?php echo $langue == "fr" ? projectnomFR : projectnomEN;?></font></th>
							<th class="text-center" bgcolor="#BCCCE1"><?php echo $langue == "fr" ? statutFR : statutEN;?></th>
						</tr>
						</thead>
						<tbody>
							<?php include('../controllerContact/tableauProjetContact.php'); ?>
						</tbody>
					</table>
				</div>


				<div class="col-xs-11 text-right">
					<a href="listeContacts.php" class="btn btn-primary btn-md"><?php echo $langue == "fr" ? retourFR : retourEN;?> </button></a>
		 		</div>
		</body>
</html>
