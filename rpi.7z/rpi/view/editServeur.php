<?php require_once('../controller/traduction.php');
// $idServeur=$_GET['idServeur']; ?>
<!DOCTYPE html>

<!-- encodage utf-8-->
<meta http-equiv="content-type" content="text/html" charset="utf-8">
<!-- Extension jQuery-->
<script type='text/javascript' src='../extension/jquery-3.3.1.min.js'></script>
<!--Extension Bootstrap--->
<link rel="stylesheet" href="../extension/bootstrap/css/bootstrap.min.css"/>
<script src="../extension/bootstrap/js/bootstrap.min.js"></script>
<!--Ajout CSS-->
<link rel="stylesheet" href="css/default.css"/>
<?php
$idServeur=$_GET['serveur'];
include("../controllerServeur/requeteDetailServer.php");
?>


<head>
    <title> <?php echo $langue == "fr" ? detailServeurFR : detailServeurEN; ?> </title>

    <!--Navbar fixé en haut-->
    <?php include('menu.php');?>

    <div class="container text-center">
	    <h1>
		    <u><?php echo $langue == "fr" ? editerboutonFR : editerboutonEN; ?></u>
	    </br>
	    </h1>
    </div>
</head>

<body>
    </br>
    </br>
    </br>
    <div class=container>
        <div class="panel panel-default">
            <div class="panel-heading"><p class="text-center"><strong><?php echo $langue == "fr" ? detailsFR : detailsEN; ?></strong></p></div>
            <div class="panel-body">

                <form method="post" action="../controllerServeur/editionServeur.php?serveur=<?php echo $idServeur;?>">

                    <div class="block pull-left" style="padding-left:50px;">
                        <input type="hidden" name="<?php echo $idServeur;?>" value="<?php echo $idServeur;?>">
                        <strong><?php echo $langue == "fr" ? nomFR : nomEN;?></strong> <input id="inputnom" name="nom" size="12" type="text" class="form-control" value='<?php echo $nom?>' /></br>
                        <strong><?php echo $langue == "fr" ? adresseIpFR : adresseIpEN;?></strong> <input id="inputip" name="ip" class="form-control col-sm-4" type="text" value='<?php echo $ip;?>' /></br>
                        <strong><?php echo $langue == "fr" ? typeAccesFR : typeAccesEN;?></strong> <input id="inputacces" name="acces" class="form-control col-sm-4" type="text" value='<?php echo $acces; ?>' /></br>
                    </div>

                    <div class="block pull-right" style="padding-right:50px;">
                        <strong><?php echo $langue == "fr" ? typecompteFR : typecompteEN;?></strong>
                        <input id="inputcompte" name="compte" type=text class=" form-control col-sm-4" value='<?php echo $compte;?>' /></br>
                        </br>
                        <strong><?php echo $langue == "fr" ? serveurtestFR : serveurtestEN;?></strong>
                        <select name="test" class="form-control form-control-sm btn dropdown-toggle text-left" action="editServeur.php">
                        <?php
                            if($test==1) {
                                echo "<option value = '1' selected>".($langue == "fr" ? ouiFR : ouiEN)."</option>";
                                echo "<option value = '0'>".($langue == "fr" ? nonFR : nonEN)."</option>";
						    }
                            else {
                                echo "<option value = '1'>".($langue == "fr" ? ouiFR : ouiEN)."</option>";
                                echo "<option value = '0' selected>".($langue == "fr" ? nonFR : nonEN)."</option>";
                            }
                        ?>
                        </select>
	    			    </br></br></br></br>

            </div>
        </div>
    </div>
    <div class="container">
      <div class="block pull-left" style="margin-left:75px;">
          <input type="submit" name="Renvoi" class="btn btn-success btn-md" value="<?php echo $langue == "fr" ? validerFR : validerEN; ?>">
      </div>
    <div class="block pull-right" style="margin-right:75px;">
	    <?php
		    echo "<a href='unServeur.php?serveur=".$idServeur."' class='btn btn-primary btn-sm'>";
		    echo $langue == "fr" ? retourFR : retourEN;
		?></a>
    </div>
	</form>
</body>
</html>
