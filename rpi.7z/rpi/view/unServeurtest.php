<?php require_once('../controller/traduction.php'); ?>
<!DOCTYPE html>
<html lang="en-US">

<!-- encodage utf-8-->
<meta http-equiv="content-type" content="text/html" charset="utf-8">

<!-- Extension jQuery-->
<script type='text/javascript' src='../extension/jquery-3.3.1.min.js'></script>
<!--Appel de notre ajax--->
<!--<script type='text/javascript' src='../scriptForm.js'></script>--->
<!--Extension Bootstrap--->
<link rel="stylesheet" href="../extension/bootstrap/css/bootstrap.min.css"/>
<script src="../extension/bootstrap/js/bootstrap.min.js"></script>
<!--Ajout CSS-->
<link rel="stylesheet" href="css/default.css"/>
<?php
$idServeur=$_GET['serveur'];
include("../controllerServeur/requeteDetailServer.php");
echo $idServeur;
?>
