<?php require_once('../controller/traduction.php'); ?>
<!DOCTYPE html>
<html lang="en-US">

<!-- encodage utf-8-->
<meta http-equiv="content-type" content="text/html" charset="utf-8">

<!-- Extension jQuery-->
<script type='text/javascript' src='../extension/jquery-3.3.1.min.js'></script>

<!--Extension Bootstrap--->
<link rel="stylesheet" href="../extension/bootstrap/css/bootstrap.min.css"/>
<script src="../extension/bootstrap/js/bootstrap.min.js"></script>
<!--Ajout CSS-->
<link rel="stylesheet" href="css/default.css"/>
<?php $idProjet = $_GET['projet'];
include('../controllerProjet/requetedetailprojet.php');

?>


<head>
	<title>
		<?php echo $langue == "fr" ? detailProjetFR : detailProjetEN; ?>
	</title>

	<!--Navbar fixé en haut-->
	<?php include('menu.php'); ?>

<div class="container text-center">
	<h1>
		<u><?php echo $langue == "fr" ? editerboutonFR : editerboutonEN; ?></u>
	</br>
	</h1>
</div>

</head>

<body>
	<div class="container center-block form-group row">
		<form class= method="post" action="../controllerProjet/editionProjet.php?projet=<?php echo $idProjet;?>">
		<div class=" espace panel panel-default center-block col-sm-12" style="padding-bottom:0px;margin-right: 0px;right: 5px;margin-left: 0px;">
			<div class="panel-heading text-center"><strong><?php echo $langue == "fr" ? projetFR : projetEN; ?></strong></div></br>
				<div class="panel-body" style="padding-bottom:0px; padding-top:0px">
					<div class="block pull-left" style="margin-left:75px;">
						<strong><?php echo $langue == "fr" ? nomProjetFR : nomProjetEN;?></strong> <input id="inputclient" type="text" class="form-control form-control-sm" name="nomProjet" value='<?php echo $nomProjet; ?>' />
				</div>
				<div class="block pull-right" style="margin-right:75px;">
					<strong><?php echo $langue == "fr" ? clientFR : clientEN;?></strong> <input id="inputclient" type="text" class="form-control form-control-sm" name="nomClient" value='<?php echo $nomClient; ?>' />
				</div>
				</div>
			</div>

			<div class="espace panel panel-default pull-left col-sm-4">
				<div class="panel-heading text-center"><b> <?php echo $langue == "fr" ? planningFR : planningEN;?> </b></span></div>
					<div class="panel-body">

					 <strong>
					  <?php echo $langue == "fr" ? dateDebutFR : dateDebutEN; ?></strong>
						<input type="date" id="datedebut" name='dateDebut' size='9' class="form-control"
									 value='<?php $dateformate = substr($dateDebut,8,2)."/".substr($dateDebut,5,2)."/".substr($dateDebut,0,4); echo $dateformate; ?>' />
					 <script type="text/javascript">
						 $(function()
									 {

														$( "#datedebut" ).datepicker({dateFormat: 'dd/mm/yyyy','defaultDate': {  year: <?php echo substr($dateDebut,0,4);?>, month: <?php echo substr($dateDebut,5,2);?>,day: <?php echo substr($dateDebut,8,2);?>}})


    												$("#icon").click(function() { $("#datedebut").datepicker( "show" );})
										});
						</script>

				 </br></br></br>


					 <strong><?php echo $langue == "fr" ? dateFinFR : dateFinEN; ?></strong>
					 <input type="date" id="datefin" name='dateFin' size='9' class="form-control" value="<?php echo $dateFin; ?>" /></br></br>
					 </br>
						<script type="text/javascript">
							$(function()
										{
														 $( "#datefin" ).datepicker();
														 $("#icon").click(function() { $("#datefin").datepicker( "show" );})
										 });
						 </script>

						  <strong><?php echo $langue == "fr" ? derniereModificationFR : derniereModificationEN; ?></strong><input type="date" id="datemodif" name='dateModification' size='9' class="form-control" value="<?php echo $dateModification; ?>" />
						 </br>
							<script type="text/javascript">
								$(function()
											{
															 $( "#datemodif" ).datepicker();
															 $("#icon").click(function() { $("#datemodif").datepicker( "show" );})
											 });
							 </script>
				</div>
			</div>

	<div class="espace panel panel-default pull-right col-sm-7">
		<div class="panel-heading text-center"><strong><?php echo $langue == "fr" ? detailProjetFR : detailProjetEN; ?><strong></div>
		<div class="panel-body">
					 <strong><?php echo $langue == "fr" ? projetInterneFR : projetInterneEN; ?>  </strong><input id="inputatos" type="text" name="interne" class="form-control form-control-sm" value='<?php echo $proprieteAtos; ?>'/></br></br>
					 <strong> <?php echo $langue == "fr" ? statutFR : statutEN; ?> </strong><input id="inputstatut" type="text" name="staut" class="form-control form-control-sm" value='<?php echo $statut; ?>' /></br></br>
					 <strong><?php echo $langue == "fr" ? dependanceFR : dependanceEN; ?></strong><input id="inputdependancy" type="text" name="dependance" class="form-control form-control-sm" value='<?php echo $dependance; ?>' /></br></br>
					 <strong><?php echo $langue == "fr" ? technoUtiliseeFR : technoUtiliseeEN; ?></strong><input id="inputtechno" type="text" name="technologieUtilisee" class="form-control form-control-sm" value='<?php echo $technologieUtilisee; ?>' /></br></br>
					 <strong><?php echo $langue == "fr" ? tagsFR : tagsEN; ?></strong><input id="inputtags" type="text" name="tags" class="form-control form-control-sm" value='<?php echo $tag; ?>' /></br></br>
					 <strong> <?php echo $langue == "fr" ? descriptionFR : descriptionEN; ?> </strong><textarea id="inputdescription" name="description" class="form-control"><?php echo $description; ?></textarea></br></br>
					 <strong> <?php echo $langue == "fr" ? commentaireFR : commentaireEN; ?>   </strong><textarea id="inputcomment" type="text" name="commentaire" class="form-control"><?php echo $commentaire; ?></textarea></br></br>
					 <strong> <?php echo $langue == "fr" ? documentationFR : documentationEN; ?></strong><textarea id="inputdoc" type="text" name="documentation" class="form-control form-control-sm"><?php echo $documentation; ?></textarea></br></br>
				</div>
			</div>


			<div class=" espace panel panel-default pull-left col-sm-4" style="padding-bottom:0px;">
				<div class="panel-heading text-center"><strong><?php echo $langue == "fr"? hebergeurFR : hebergeurEN; ?></strong></div>
				<div class="panel-body">
					<div class="block pull-left">
						<strong><?php echo $langue == "fr" ? ipBddFR : ipBddEN; ?> </strong><input id="inputipBdd" type="text" name="ipBdd" class="form-control form-control-sm" value='<?php echo $ipBdd?>' /></br>
						<strong><?php echo $langue == "fr" ? bddFR : bddEN; ?> </strong><input id="inputserver" type="text" name="bdd" class="form-control form-control-sm" value='<?php echo $nomBdd?>' /></br>
					</div>
					<div class="block pull-left">
					<strong><?php echo $langue == "fr" ? adresseIpFR : adresseIpEN; ?> </strong><input id="inputserver" type="text" name="ipServeur" class="form-control form-control-sm" value='<?php echo $ipBdd?>' /></br>
					<strong><?php echo $langue == "fr" ? serveursFR : serveursEN; ?> </strong><input id="inputserver" type="text" name="serveur" class="form-control form-control-sm" value='<?php echo $nomBdd ?>' /></br>
					</div>
				</div>
			</div>
		</form>


			<div class="container col-sm-12">
				<div class="pull-left" style="margin-left:75px; padding-bottom:75px;">
					<input type="submit" name="Renvoi" class="btn btn-success btn-sm" value="<?php echo $langue == "fr" ? validerFR : validerEN; include("../controllerProjet/editionprojet.php");?>">
				</div>
			<div class="pull-right" style="margin-right:75px;">
			    <?php
				    echo "<a href='Unprojet.php?projet=".$idProj."' class='btn btn-primary btn-sm'>";
                    echo $langue == "fr" ? retourFR : retourEN;
				?></a>
			</div>
			</div>
</body>
</html>
