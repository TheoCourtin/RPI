<?php require_once('../controller/traduction.php'); ?>
<!DOCTYPE html>
<html lang="en-US">

<!-- encodage utf-8-->
<meta http-equiv="content-type" content="text/html" charset="utf-8">

<!-- Extension jQuery-->
<script type='text/javascript' src='../extension/jquery-3.3.1.min.js'></script>
<!--Appel de notre ajax--->
<!--<script type='text/javascript' src='../scriptForm.js'></script>--->
<!--Extension Bootstrap--->
<link rel="stylesheet" href="../extension/bootstrap/css/bootstrap.min.css"/>
<script src="../extension/bootstrap/js/bootstrap.min.js"></script>
<!--Ajout CSS-->
<link rel="stylesheet" href="css/default.css"/>
<?php
$idServeur=$_GET['serveur'];
include("../controllerServeur/requeteDetailServer.php");
?>


<head>

	<title>
		<?php echo $langue == "fr" ? serveurdetailFR : serveurdetailEN;?>
	</title>

	<!--Navbar fixé en haut-->
	<?php include('menu.php');?>


	<h1 class="text-center">
		<div class="encadrement cadre">
		<font color="white"><?php echo $nom;?></font>

		</div>
	</h1>

	<div class="espace pull-right">
	    <?php
          $trad =$langue == "fr" ? editerboutonFR : editerboutonEN;
	        echo "<a href ='editServeur.php?serveur=$idServeur' class='btn btn-md btn-danger'>".$trad."</a>";
        ?>
	</div>

	</br>
</head>

<body>
</br>
</br>
</br>
	<div class="container">
		<div class="panel panel-default">
            <div class="panel-heading text-center"><strong><h4><?php echo $langue == "fr" ? detailsFR : detailsEN; ?></h4></strong></div>
            <div class="panel-body">
            <div class="block pull-right" style="margin-right:75px;">
                <strong><?php echo $langue == "fr" ? adresseIpFR : adresseIpEN;?></strong> : <?php echo $ip; ?></br>
                <strong><?php echo $langue == "fr" ? serveurtestFR : serveurtestEN;?></strong> :
				<?php
				    if ($langue=="fr")
                        echo $test == "1" ? ouiFR : nonFR;
					else
                        echo $test == "1" ? ouiEN : nonEN;
				?>
				</br>
            </div>
						
            <div class="block pull-left" style="margin-left:75px;">
                <strong><?php echo $langue == "fr" ? typeAccesFR : typeAccesEN;?></strong> : <?php echo $acces; ?></br>
                <strong><?php echo $langue == "fr" ? typecompteFR : typecompteEN;?></strong> : <?php echo $compte; ?></br>
            </div>
        </div>
    </div>

	  <table class="table table-bordered table-hover">
	    <thead>
	      <h4 class="text-center"><b> &nbsp;<?php echo $langue == "fr" ? ListeBddFR : listeBddEN;?>  </b> </h4> </br>
	      <tr>
	        <th class="text-center" bgcolor="#BCCCE1"><?php echo $langue == "fr" ? nomBddFR : nomBddEN;?></u></strong></th>
	        <th class="text-center" bgcolor="#BCCCE1"><?php echo $langue == "fr" ? ipBddFR : ipBddEN;?> </u></strong></th>
	      </tr>
	    </thead>
	    <tbody>
	      <tr>
	        <?php
	        include('../controllerServeur/tableauserveurbdd.php');?>
	      </tr>
	    </tbody>
	  </table>
	</div>

	<div class="espace pull-right">
		<a href="listeServeurs.php" class="btn btn-primary btn-md"><?php echo $langue == "fr" ? retourFR : retourEN;?> </button></a>
	</div>
</body>
</html>
