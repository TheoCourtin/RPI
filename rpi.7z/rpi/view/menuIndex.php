<!--Navbar fixé top-->
<link rel="icon" type="image/png" href="img/logo_unity.png"/>
<nav class ="navbar navbar-static-top" style="background-color: #5499c7;" id="navbar">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand"><img class="pull-left" src="img/atos.png" alt="AtoS - ISM" height="20"></a>
        </div>
        <div class="centrageTitre">
            <h3><b>
            <?php echo $langue == "fr" ? referentielFR : referentielEN;?>
            </b></h3>
        </div>
	</div>
</nav>
