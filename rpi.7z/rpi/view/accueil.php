<?php
require_once('../controller/traduction.php');
?>
<!DOCTYPE html>

<!--Encodage de la page-->
<meta http-equiv="content-type" content="text/html" charset="utf-8">
<!-- Langue par défaut -->
<html lang="en-US">

<!-- Extension jQuery-->
<script type='text/javascript' src='../extension/jquery-3.3.1.min.js'></script>
<!--Appel de notre ajax-->
<script type='text/javascript' src='../loginaj.js'></script>
<!--Extension Bootstrap-->
<link rel="stylesheet" href="../extension/bootstrap/css/bootstrap.min.css"/>
<script src="../extension/bootstrap/js/bootstrap.min.js"></script>
<!--Ajout CSS-->
<link rel="stylesheet" href="css/default.css"/>
<link rel="icon" href="../img/logo_unity.ico" />

<head>
	<title>

		<?php
		echo $langue == "fr" ? pageAccueilFR : pageAccueilEN;
		/*	if($langue == "fr") {
				echo pageAccueilFR;
			}
			else if ($langue == "en") {
				echo pageAccueilEN;
			}*/
		?>
	</title>
	<!--Navbar fixé en haut-->
	<?php include('menu.php');?>

</head>

<body>
	<div class="emplacement">

			<!--tableau qui affiche les 10 derniers projets modifiés-->
			<div class="col-xs-12 col-md-6">
				<div class="espace">
					<table class="table table-bordered table-hover">
						<thead>
							<h2 class="text-center">
								<u><?php
								echo $langue == "fr" ? derniersProjetsFR : derniersProjetsEN;
								?></u>
							</h2> </br>
							<tr style="background-color: #BCCCE1">
							<th class="text-center">
								<?php
									echo $langue == "fr" ? nomFR : nomEN;
								?>
							</th>
							<th class="text-center">
								<?php
								echo $langue == "fr" ? derniereModificationFR : derniereModificationEN;
								?>
							</th>
						</tr>
						</thead>
						<tbody>
						<?php include("../TableauSelect.php"); ?>
						</tbody>
					</table>
				</div>
			</div>
			<!-- Les 10 derniers projets de l'utilisateur-->
			<div class="col-xs-12 col-md-6">
				<div class="espace">
					<table class="table table-bordered table-hover">
						<thead>
							<h2 class="text-center">
								<u><?php
								echo $langue == "fr" ? vosDerniersProjetsFR : vosDerniersProjetsEN;
								?></u>
							</h2> </br>
							<tr style="background-color: #BCCCE1">
							<th class="text-center">
								<?php
								echo $langue == "fr" ? nomFR : nomEN;
								?>
							</th>
							<th class="text-center">
								<?php
								echo $langue == "fr" ? derniereModificationFR : derniereModificationEN;
								?>
							</th>
							</tr>
						</thead>
						<tbody>
							<?php include("../tableauUserAccueil.php"); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>

</body>

</html>
