<?php
// On détruit les variables de la session
session_start();
unset($_SESSION['das']);
session_destroy();
// session_write_close();
// setcookie(session_name(),'',0,'/');
//
// setcookie($das);
// setcookie($password);
// On redirige le visiteur vers la page de login
header ('location: index.php');
exit;
?>
