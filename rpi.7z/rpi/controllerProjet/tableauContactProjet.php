<?php
// header('contant-type : text/html; charset=utf-8');

$idProj = $_GET['projet']; //vérifier si la variable est correct (int non vide)
//echo json_encode();

//connexion à la base de donnée
$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';

$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("SELECT * FROM contact WHERE idContact =".$idContact);
$sth->execute();
$resultContact = $sth->fetchAll();

foreach ($resultContact as $key=>$value) {
	$idContact = $value['idContact'];
	echo "<td align='center'>".$value['nom']." ".$value['prenom']."</td>";
	echo "<td align='center'>".$GET['email'] = $value['email']."</td>";
	echo "<td align='center'>".$GET['telephone'] = $value['telephone']."</td>";
}
