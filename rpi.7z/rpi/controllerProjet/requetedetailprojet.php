<?php
// header('contant-type : text/html; charset=utf-8');

$idProj = $_GET['projet']; //vérifier si la variable est correct (int non vide)
// echo json_encode();

//connexion à la base de donnée
$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';

//requête sql
$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("SELECT * from projet where idProjet=$idProj");
$sth->execute();
$resultProjet = $sth->fetchAll();
//var_dump($result);

//On définie des variables globales
foreach ($resultProjet as $key=>$value) {
	$idProjet=$value['idProjet'];
	$nomProjet = $value['nomProjet'];
	$description= $value['description'];
	$tag = $value['tag'];
	$dateDebut= $value['dateDebut'];
	$dateFin= $value['dateFin'];
	$statut = $value['statut'];
	if ($value['proprieteAtos']==1)
		{$proprieteAtos = 'Yes';}
	else{
		$proprieteAtos = 'No';}
	$technologieUtilisee= $value['technologieUtilisee'];
	$documentation = $value['documentation'];
	$dependance = $value['dependance'];
	$dateModification = $value['dateModification'];
	$commentaire = $value['commentaire'];
//Clé étrangère
	$idContact = $value['idContact'];
	$idServeur = $value['idServeur'];
	$idClient = $value['idClient'];
	$idUtilisateur = $value['idUtilisateur'];
	$idBdd = $value['idBdd'];
}

//Renseignement bdd
$sth = $dbh->prepare("SELECT * FROM bdd WHERE idBdd=".$idBdd);
$sth->execute();
$resultBdd = $sth->fetchAll();

foreach ($resultBdd as $key=>$value) {
	$idBdd = $value['idBdd'];
	$nomBdd = $value['nom'];
	$ipBdd = $value['ip'];
}
//Renseignement serveur
$sth = $dbh->prepare("SELECT * FROM serveur WHERE idServeur=".$idServeur);
$sth->execute();
$resultServeur = $sth->fetchAll();

foreach ($resultServeur as $key=>$value) {
	$idServer = $value['idServeur'];
	$nomServer = $value['nom'];
	$ipServer = $value['ip'];
}

//Renseignement Client
$sth = $dbh->prepare("SELECT * FROM client WHERE idClient=".$idClient);
$sth->execute();
$resultClient = $sth->fetchAll();

foreach ($resultClient as $key=>$value) {
	$nomClient = $value['nom'];
}

//Information Utilisateur
$sth = $dbh->prepare("SELECT * FROM utilisateur WHERE idUtilisateur=".$idUtilisateur);
$sth->execute();
$resultUtilisateur = $sth->fetchAll();

foreach ($resultUtilisateur as $key=>$value) {
	$nomUtilisateur = $value['nom'];
	$prenomUtilisateur = $value['prenom'];
}
?>
