<?php
// header('contant-type : text/html; charset=utf-8');

$idProj = $_GET['projet']; //vérifier si la variable est correct (int non vide)
// echo json_encode();

//connexion à la base de donnée
$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';

//requête sql
$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("UPDATE projet SET where idProjet=$idProj");
$sth->execute();
$resultProjet = $sth->fetchAll();
?>
