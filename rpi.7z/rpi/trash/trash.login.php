<?php
require("model/login.class.php");
require("model/Att11CC.tmp.class.php");
//on démarrer la session
session_start();

//instanciation les variables das et password
$das=$_POST["das"];
$password=$_POST["password"];


if (!empty($das) && !empty($password)){
  //instancie une nouvelle authentification puis on fait la connexion
  $obj_ldap = new auth_ldap($das, $password);

  if($obj_ldap->get_connexion()){
    //si on est ok sur la connexion LDAP on verifie si l'utilisateur a accès à ce service
    //On instancie le nouvel utilisateur
    $User = new User($das, $password);
    //on vérifie
    if($User->check_user($das,$password)){
      echo "";
	  $_SESSION['das'] = $das;
      }
    else{
      echo "You can't have access to this service";
    }
  }
  else {
      echo "Login and password aren't matching";
    }
 }
 else {
   echo "Incorrect fields";
 }
 var_dump($das, $password);
