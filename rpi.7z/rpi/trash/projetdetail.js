    $(document).ready(function () {
    //    $('[data-toggle="popover"]').popover({
      //      title: setData,
      //      html: true,
      //      placement:'right'
      function afficherUnDetail($test) {

            var idProjet = $('#idProjet').val; //$(Selector).attr(attribute)
            $.ajax({
                url: "view/Unprojet.php?projet" + idProjet, //requetedetailprojet.php
                type: "POST", //car on recupère l'id juste au-dessus le get ne sers plus
                dataType: "json", //on encode en json donc on a bien un type json
                data: {idProjet : idProjet},

                success: function(data) {
                    $("#afficherUnDetail").load("Unprojet.php?projet="+id);
                },
                error: function(e) {
                  console.log(e)
                }
            });
        };
      });

      //  $('.jesaispas').click(function(event) {
      //      afficherUnDetail($(this));
      //  });
      //  function setData(id) {
      //      var set_data = '';
        //    var element = $(this);
      //      var id = element.attr("id");
      //      $.ajax({
      //          url: "/view/Unprojet.php" + id,
      //          method: "GET",
      //          async: false,
        //        data: { id: id },
        //        success: function (data) {
        //            set_data = data;
        //        }

      //      });
      //      return set_data;
    //});
