<?php require_once('connexion.class.php');

Class Projet extends Connection {

  public function __construct()
    {

    }


  function AfficheProjets ()
  {
    $req = $db->prepare("SELECT nom, statut, dateModification FROM projet ORDER BY dateModification DESC LIMIT 10");
    $req->execute();
    return $req;
  }
}
