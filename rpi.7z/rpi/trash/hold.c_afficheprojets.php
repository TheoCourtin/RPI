<?php include('model/listeprojet.class.php');
require("model/connexion.class.php");

$tab = new Connection;
$res = $tab->AfficheProjets();
while ($row = $req->fetch())
{

}
//require('tableau_sql.php');
