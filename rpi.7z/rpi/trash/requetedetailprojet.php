<?php
$idProj = $_GET['projet']; //vérifier si la variable est correct (int non vide)
echo json_encode();

//connexion à la base de donnée
$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';

//requête sql
$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("SELECT * from projet where idProjet=$idProj");
$sth->execute();
$resultProjet = $sth->fetchAll();
//var_dump($result);

//On définie des variables globales
foreach ($resultProjet as $key=>$value) {
	$GET['idProjet']=$value['idProjet'];
	$GET['nomProjet'] = $value['nomProjet'];
	$GET['description'] = $value['description'];
	$GET['tag'] = $value['tag'];
	$GET['dateDebut'] = $value['dateDebut'];
	$GET['dateFin'] = $value['dateFin'];
	$GET['statut'] = $value['statut'];
	if ($value['proprieteAtos']==1)
		{$GET['proprieteAtos'] = 'Yes';}
	else{
		$GET['proprieteAtos'] = 'No';}
	$GET['technologieUtilisee'] = $value['technologieUtilisee'];
	$GET['documentation'] = $value['documentation'];
	$GET['dependance'] = $value['dependance'];
	$GET['dateModification'] = $value['dateModification'];
	$GET['commentaire'] = $value['commentaire'];
//Clé étrangère
	$idContact = $value['idContact'];
	$idServeur = $value['idServeur'];
	$idClient = $value['idClient'];
	$idUtilisateur = $value['idUtilisateur'];
}

//Information Contact
$sth = $dbh->prepare("SELECT * FROM contact WHERE idContact =".$idContact);
$sth->execute();
$resultContact = $sth->fetchAll();

foreach ($resultContact as $key=>$value) {
	$GET['idContact']=$value['idContact'];
	$GET['dasContact'] = $value['das'];
	$GET['nomContact'] = $value['nom'];
	$GET['prenomContact'] = $value['prenom'];
	$GET['fonction'] = $value['fonction'];
	$GET['email'] = $value['email'];
	$GET['telephone'] = $value['telephone'];
}

//Renseignement serveur
$sth = $dbh->prepare("SELECT * FROM serveur WHERE idServeur=".$idServeur);
$sth->execute();
$resultServeur = $sth->fetchAll();

foreach ($resultServeur as $key=>$value) {
	$GET['idServer'] = $value['idServeur'];
	$GET['nomServer'] = $value['nom'];
	$GET['ipServer'] = $value['ip'];
}

//Renseignement Client
$sth = $dbh->prepare("SELECT * FROM client WHERE idClient=".$idClient);
$sth->execute();
$resultClient = $sth->fetchAll();

foreach ($resultClient as $key=>$value) {
	$GET['nomClient'] = $value['nom'];
}

//Information Utilisateur
$sth = $dbh->prepare("SELECT * FROM utilisateur WHERE idUtilisateur=".$idUtilisateur);
$sth->execute();
$resultUtilisateur = $sth->fetchAll();

foreach ($resultUtilisateur as $key=>$value) {
	$GET['nomUtilisateur'] = $value['nom'];
	$GET['prenomUtilisateur'] = $value['prenom'];
}
?>
