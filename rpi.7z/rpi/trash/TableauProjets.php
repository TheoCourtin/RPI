<?php

// Ajout CSS
echo '<link rel="stylesheet" href="view/css/default.css"/>';

header('content-type: text/html; charset=utf-8');
//connexion à la base de données
$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';
//requête sql
$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("SELECT idProjet, nomProjet, dateDebut, dateFin, statut, dateModification, commentaire, description FROM projet ORDER BY nomProjet");
$sth->execute();
$result = $sth->fetchAll();
//var_dump($result);

//Récupération de toutes les lignes d'un jeu de résultats */
//print("Récupération de toutes les lignes d'un jeu de résultats :\n");
//$result = $sth->fetchAll();
//print_r($result);
//tableau ou le resutat de la requête est stockée
  foreach ($result as $key=>$value){
    $idProjet = $value['idProjet'];
    echo "<tr>";
    echo "<td align='center'><a href='../view/Unprojet?projet=$idProjet'>".$value['nomProjet']."</a></td>";
    echo "<td align='center'>".$value['description']."</td>";
    echo '<td align="center"><input style="text-align:center;" id="date" size="9" disabled="disabled" value='.$value['dateDebut'].'></td>';
    echo '<td align="center"><input style="text-align:center;" id="date" size="9" disabled="disabled" value='.$value['dateFin'].'></td>';
    echo "<td align='center'>".$value['statut']."</td>";
    echo "<td align='center'>".$value['dateModification']."</td>";
    echo "</tr>";
 }
