<?php
$user = 'rpi';
$password = '9vaYRPKjfJnmtrJZ';
$serverLink = 'ms-apps.fr.atos.net';
$dbName = 'rpi';
$das = "a734529";

$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password);
$sth = $dbh->prepare('SELECT projet.nom, statut, dateModification, das FROM projet INNER JOIN utilisateur on projet.idUtilisateur = projet.idUtilisateur
WHERE utilisateur.das =."$das". ORDER BY dateModification DESC LIMIT 10');
$sth->execute();
$result = $sth->fetchAll();

var_dump($result);
//Récupération de toutes les lignes d'un jeu de résultats */
//print("Récupération de toutes les lignes d'un jeu de résultats :\n");
//$result = $sth->fetchAll();
//print_r($result);

  foreach ($result as $key=>$value){
        echo  '<tr>';
        for($i=0; $i<count($value); $i++){
              echo '<td>'.$value[$i].'</td>';
            }
        echo '</tr>';
    }

?>
<meta charset="utf-8">
<table class="table table-bordered">
  <thead>
    <th><p>DAS</p></th>
    <th><p>Nom</p></th>
    <th><p>Statut</p></th>
    <th><p>Date de dernière modification</p></th>
  </thead>
  <tbody>
