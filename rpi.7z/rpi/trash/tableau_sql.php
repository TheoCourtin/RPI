<?php
require_once("model/hold.listeprojet.class.php");

$desProjet=new Projet();
$projet=$desProjet->AfficheProjets();

 while ($row = $projet->fetch()){
  echo '<tr>';
  echo '<td>'.$row['nom'].'</td>';
  echo '<td>'.$row['statut'].'</td>';
  echo '<td>'.$row['dateModification'].'</td>';
  echo '</tr>';
}?>
