<?php
header('contant-type : text/html; charset=utf-8');

$idProj = $_GET['projet']; //vérifier si la variable est correct (int non vide)
echo json_encode();

//connexion à la base de donnée
$user = 'rpi';
$password = '9vaYRPKjfJnmtrJZ';
$serverLink = 'ms-apps.fr.atos.net';
$dbName = 'rpi';

//requête sql
$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("SELECT * from projet where idProjet=$idProj");
$sth->execute();
$result = $sth->fetchAll();
var_dump($result);

//stocké le resultat dans un formulaire/tableau (bref on fait comme on peut)
foreach ($result as $key=>$value){
      echo "<strong>Nom du projet : </strong>".$value['nomProjet'];
      echo "<strong>Description : </strong>".$value['description'];
      echo "<strong>Date de début : </strong>".$value['dateDebut'];
      echo "<strong>Date de fin : </strong>".$value['dateFin'];
      echo "<strong>Statut : </strong>".$value['statut'];
      echo "<strong>Propriété de Atos : </strong>".$value['proprieteAtos'];
}
