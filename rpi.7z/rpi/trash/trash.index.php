<?php
//Appelle de la connexion
require_once('model/connexion.class.php');
?>
<!DOCTYPE html>
<html lang="en-US">

<!-- encodage utf-8-->
<meta http-equiv="content-type" content="text/html" charset="utf-8">

<!-- Extension jQuery-->
<script type='text/javascript' src='extension/jquery-3.3.1.min.js'></script>
<!--Appel de notre ajax--->
<script type='text/javascript' src='scriptForm.js'></script>
<!--Extension Bootstrap--->
<link rel="stylesheet" href="extension/bootstrap/css/bootstrap.min.css">
<script src="extension/bootstrap/js/bootstrap.min.js"></script>


<head>
<!--entête ou se trouvera le logo-->
	<nav class="navbar narvba-fixed-top" style="background-color: #5499c7">
		<div class="text-center text-capitalize">
			<strong>Logo en cours de développement</strong>
		</div>
	</nav>

</head>

<body>
<!--Formulaire-->
	<div class="container" id="div-login">

		<form class="form-horizontal block-center" role="form" id="login" method="POST" action="">

			<div class="login-body login-night text-center " style="margin:auto;">

				<h1>
					Login
				</h1>

				<div class="input-group" style="margin:auto;">
					<label class="col-xs-2 control-label"><img src="img/login.png"></label>
					<div class="col-xs-10">
						<input type="das" class="form-control" id="inputdas" placeholder="DAS"></br>
					</div>
				</div>

				<div class="input-group" style="margin:auto;">
				</br><label class="col-xs-2 control-label"><img src="img/cadenas.png"></label>
					<div class="col-xs-10">
			      <input type="password" class="form-control" id="inputPassword3" placeholder="Password"></br></br>
			    </div>
			  </div>

				</div>

				<div class="text-center">
				</br><a class="text-muted nav-link" href="https://www.myatos.net/" target="_blank"> Forgot your password ? </a></br></br>

					<!-- Réponse de la connexion -->
					<div class="col-xs-12 text-center">
						<!--<div class=" alert alert-content alert-danger" style="margin:auto" ></br></div>-->
						<input type="submit" class="btn btn-muted btn-lg" value="Enter" style="margin:auto;"/>

					</div>

			</form>
		</div>

<!--navbar fixé en bas avec les logos-->
		<nav class="navbar navbar-fixed-bottom hidden-xs navbar-footer" id="footer" role="footer">
		  <img class="pull-left" src="img/atos.png" alt="AtoS">
		  <img class="pull-right" src="img/logo_ism.png" alt="ISM">
		</nav>

</body>

</html>
