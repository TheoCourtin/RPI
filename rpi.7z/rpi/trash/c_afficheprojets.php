<?php require_once('model/listeprojet.class.php');
require_once("model/connexion.class.php");

$tab = new Projet;
$res = $tab->AfficheProjets();
while ($row = $req->fetch())
{

}
//require('tableau_sql.php');
