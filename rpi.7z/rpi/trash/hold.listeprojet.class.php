<?php require('connexion.class.php');

Class Projet {


  function AfficheProjets ()
  {
    $req = $db->prepare("SELECT nom, statut, dateModification FROM projet ORDER BY dateModification DESC LIMIT 10");
    $req->execute();
    return $req;
  }
}
