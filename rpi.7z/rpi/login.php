<?php
require("model/login.class.php");
// require("model/Att11CC.tmp.class.php");
require_once('controller/traduction.php');
//$_SESSION['das'];

//instanciation les variables das et password
$das=$_POST["das"]; //strtoupper
$password=$_POST["password"];



if (!empty($das) && !empty($password)) {
  // //instancie une nouvelle authentification puis on fait la connexion
  // $obj_ldap = new auth_ldap($das, $password);
  //
	// if($obj_ldap->get_connexion()) {
		//si on est ok sur la connexion LDAP on verifie si l'utilisateur a accès à ce service
		//On instancie le nouvel utilisateur
		$User = new User($das, $password);
		//on vérifie
		if($User->check_user($das,$password)) {
			echo "";
			$_SESSION['das'] = $das;
		}
		else {
			if($langue == "fr") {
				echo '<p class="text-danger">'.accesRefuseFR.'</p>';
			}
			else {
				echo '<p class="text-danger">'.accesRefuseEN.'</p>';
			}
		}
	}
	// else {
	// 	if($langue == "fr") {
	// 		echo '<p class="text-danger">'.idInvalideFR.'</p>';
	// 	}
	// 	else {
	// 		echo '<p class="text-danger">'.idInvalideEN.'</p>';
	// 	}
	// 	else {
	// if($langue == "fr") {
	// 	echo '<p class="text-danger">'.erreurChampsFR.'</p>';
	// }
	// else {
	// 	echo '<p class="text-danger">'.erreurChampsEN.'</p>';
	// }
 // }
 //    }


 ?>
