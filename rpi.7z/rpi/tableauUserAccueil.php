<?php
$das=strtoupper($_SESSION['das']);
// include_once('model/connexion.class.php');
$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';

$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("SELECT idProjet, nomProjet, dateModification FROM projet INNER JOIN utilisateur ON projet.idUtilisateur = utilisateur.idUtilisateur WHERE das ='$das' ORDER BY dateModification DESC LIMIT 10");
$sth->execute();
$result = $sth->fetchAll();
//var_dump($result);

//Récupération de toutes les lignes d'un jeu de résultats */
//print("Récupération de toutes les lignes d'un jeu de résultats :\n");
//$result = $sth->fetchAll();
//print_r($result);

 foreach ($result as $key=>$value){
        $idProjet = $value['idProjet'];
        echo '<tr>';
        echo "<td align='center'><a href='Unprojet.php?projet=$idProjet'>".$value['nomProjet'].'</a></td>';
        echo "<td align='center'>".$value['dateModification']."</td>";
        echo '</tr>';
    }
