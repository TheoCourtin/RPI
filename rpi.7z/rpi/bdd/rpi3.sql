-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mer. 08 mai 2019 à 13:14
-- Version du serveur :  5.7.21
-- Version de PHP :  7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `rpi3`
--

-- --------------------------------------------------------

--
-- Structure de la table `bdd`
--

DROP TABLE IF EXISTS `bdd`;
CREATE TABLE IF NOT EXISTS `bdd` (
  `idBdd` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) CHARACTER SET utf8 NOT NULL,
  `nom` varchar(20) CHARACTER SET utf8 NOT NULL,
  `typeAcces` varchar(20) CHARACTER SET utf8 NOT NULL,
  `typeCompte` varchar(20) CHARACTER SET utf8 NOT NULL,
  `idServeur` int(11) NOT NULL,
  `test` tinyint(4) NOT NULL,
  PRIMARY KEY (`idBdd`),
  KEY `idServeur` (`idServeur`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `bdd`
--

INSERT INTO `bdd` (`idBdd`, `ip`, `nom`, `typeAcces`, `typeCompte`, `idServeur`, `test`) VALUES
(1, '123.25.15.289', 'RPI', 'user', 'LDAP', 1, 0),
(2, '125.16.125.12', 'patate', 'test', 'test', 2, 1);

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `idClient` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(20) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`idClient`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`idClient`, `nom`) VALUES
(1, 'Atos');

-- --------------------------------------------------------

--
-- Structure de la table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `idContact` int(11) NOT NULL AUTO_INCREMENT,
  `das` varchar(7) CHARACTER SET utf8 NOT NULL,
  `nom` varchar(20) CHARACTER SET utf8 NOT NULL,
  `prenom` varchar(20) CHARACTER SET utf8 NOT NULL,
  `fonction` varchar(100) CHARACTER SET utf8 NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `telephone` varchar(10) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`idContact`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `contact`
--

INSERT INTO `contact` (`idContact`, `das`, `nom`, `prenom`, `fonction`, `email`, `telephone`) VALUES
(1, 'A734529', 'Dupont', 'Jean', 'Alternant', 'mail@gmail.com', '0123456789'),
(3, 'A123456', 'Fortune', 'Sarah', 'Web Developper', 'sarah.fortune@atos.net', '0123456798'),
(2, '', 'Hasagi', 'Jean', 'Manager', 'Jean.Hasagi@lol.net', '0125498476');

-- --------------------------------------------------------

--
-- Structure de la table `externe`
--

DROP TABLE IF EXISTS `externe`;
CREATE TABLE IF NOT EXISTS `externe` (
  `idContact` int(11) NOT NULL,
  `entreprise` varchar(20) CHARACTER SET utf8 NOT NULL,
  KEY `idContactExterneFK` (`idContact`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `interne`
--

DROP TABLE IF EXISTS `interne`;
CREATE TABLE IF NOT EXISTS `interne` (
  `idContact` int(11) NOT NULL,
  `das` varchar(7) CHARACTER SET utf8 NOT NULL,
  KEY `idContactInterneFK` (`idContact`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `projet`
--

DROP TABLE IF EXISTS `projet`;
CREATE TABLE IF NOT EXISTS `projet` (
  `idProjet` int(11) NOT NULL AUTO_INCREMENT,
  `idClient` int(11) NOT NULL,
  `idBdd` int(11) NOT NULL,
  `idServeur` int(11) NOT NULL,
  `idContact` int(11) NOT NULL,
  `nomProjet` varchar(20) CHARACTER SET utf8 NOT NULL,
  `description` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `tag` varchar(100) CHARACTER SET utf8 NOT NULL,
  `dateDebut` datetime NOT NULL,
  `dateFin` datetime NOT NULL,
  `statut` varchar(50) CHARACTER SET utf8 NOT NULL,
  `proprieteAtos` tinyint(1) NOT NULL,
  `technologieUtilisee` varchar(100) CHARACTER SET utf8 NOT NULL,
  `documentation` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `dependance` varchar(500) CHARACTER SET utf8 NOT NULL,
  `commentaire` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `idUtilisateur` int(11) NOT NULL,
  `dateModification` datetime NOT NULL,
  PRIMARY KEY (`idProjet`),
  KEY `idClientFK` (`idClient`),
  KEY `idServeurFK` (`idServeur`),
  KEY `idContactFK` (`idContact`),
  KEY `idUtilisateur` (`idUtilisateur`),
  KEY `idBdd` (`idBdd`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `projet`
--

INSERT INTO `projet` (`idProjet`, `idClient`, `idBdd`, `idServeur`, `idContact`, `nomProjet`, `description`, `tag`, `dateDebut`, `dateFin`, `statut`, `proprieteAtos`, `technologieUtilisee`, `documentation`, `dependance`, `commentaire`, `idUtilisateur`, `dateModification`) VALUES
(1, 1, 1, 1, 1, 'RPI', 'Inventaire des différents projets crées ainsi que les différentes base de données, serveurs et leur développeur', 'PHP', '2019-01-07 10:00:00', '2019-03-01 16:00:00', 'Terminé', 1, 'PHP, SQL, CSS, AJAX et HTML', 'Recherche internet', 'Aucune', 'Projet de stagiaire ', 1, '2019-03-04 20:28:16'),
(2, 1, 2, 1, 1, 'Ansible', 'Plateforme de logiciels', 'application web', '2019-02-11 00:00:00', '2019-02-07 00:00:00', 'En cours', 1, 'Java', 'non', 'oui', 'Plateforme regroupant plusieurs logiciels', 1, '2019-05-09 00:00:00'),
(3, 1, 1, 1, 1, 'TEST6', 'TEST', 'TEST', '2019-02-20 00:00:00', '2019-02-15 00:00:00', 'TEST', 1, 'TEST', 'TEST', 'TEST', 'TEST', 1, '2017-07-20 20:28:16'),
(4, 1, 2, 1, 1, 'Jaune', 'TEST2', 'TEST2', '2019-02-11 00:00:00', '2019-02-07 00:00:00', 'TEST2', 1, 'TEST2', 'TEST2', 'TEST2', 'TEST2', 1, '2019-02-13 00:00:00'),
(5, 1, 1, 1, 1, 'TEST3', 'TEST3', 'TEST3', '2019-02-11 00:00:00', '2019-02-15 00:00:00', 'TEST3', 1, 'TEST3', 'TEST3', 'TEST3', 'TEST3', 1, '2017-04-13 00:00:00'),
(6, 1, 2, 1, 1, 'TEST4', 'TEST4', 'TEST4', '2019-02-14 00:00:00', '2019-02-07 00:00:00', 'TEST4', 1, 'TEST4', 'TEST4', 'TEST4', 'TEST4', 1, '2013-09-09 00:00:00'),
(7, 1, 1, 1, 1, 'TEST7', 'TEST7', 'TEST7', '2019-02-07 00:00:00', '2019-02-19 00:00:00', 'TEST7', 1, 'TEST7', 'TEST7', 'TEST7', 'TEST7', 2, '2018-10-16 00:00:00'),
(8, 1, 2, 2, 1, 'TEST8', 'TEST8', 'TEST8', '2019-02-15 00:00:00', '2019-02-14 00:00:00', 'TEST8', 1, 'TEST8', 'TEST8', 'TEST8', 'TEST8', 1, '2016-05-19 00:00:00'),
(9, 1, 2, 1, 3, 'TEST9', 'TEST9', 'TEST9', '2019-02-07 00:00:00', '2019-02-28 00:00:00', 'TEST9', 1, 'TEST9', 'TEST9', 'TEST9', 'TEST9', 1, '2016-07-12 00:00:00'),
(10, 1, 1, 1, 1, 'Ten', 'suivi du chiffre d\'affaire de Ten', 'TEST10', '2019-02-01 00:00:00', '2019-06-21 00:00:00', 'Etude', 1, 'PHP, SQL, CSS, AJAX et HTML', 'non', 'non', 'Application permerttant de suivre le chiffre d\'affaire de la société', 1, '2019-06-21 00:00:00'),
(11, 1, 2, 1, 1, 'Axa', 'Affichage du nombre de client', 'logiciel', '2019-02-15 00:00:00', '2019-02-23 00:00:00', 'Etude', 1, 'C#, Windows form', 'oui', 'oui', 'Suivi des clients d\'AXA', 1, '2021-04-14 00:00:00'),
(13, 1, 1, 2, 1, 'Snow', 'Neige', 'Tag', '2019-02-04 10:03:24', '2019-02-05 10:03:29', 'Terminé', 1, 'PHP', 'Oui', 'Oui', 'Bla Bla Bla', 3, '2019-02-06 10:04:58'),
(14, 1, 2, 2, 1, 'Rubis', 'Neige', 'Tag', '2019-02-04 10:03:24', '2019-02-05 10:03:29', 'Terminé', 1, 'PHP', 'Oui', 'Oui', 'Bla Bla Bla', 4, '2019-02-06 10:04:58'),
(15, 1, 1, 2, 1, 'Kanban', 'Planificateur de tache', 'outil', '2018-11-02 14:34:05', '2019-02-28 14:35:24', 'Terminé', 1, 'AJAX, PHP, CSS, HTML', 'Non', 'Oui', 'Développer par l\'équipe Orléans', 3, '2049-03-04 14:36:10'),
(16, 1, 2, 2, 1, 'Llanfairpwllgwyngyll', 'Au courant de l\'amour lorsque je m\'abandonne, Dans le torrent divin quand je plonge enivré, Et presse éperdument sur mon sein qui frissonne Un être idolâtre.  Je sais que je n\'étreins qu\'une forme fragile, Qu\'elle peut à l\'instant se glacer sous ma main, Que ce cœur tout à moi, fait de flamme et d\'argile, Sera cendre demain ;  Qu\'il n\'en sortira rien, rien, pas une étincelle Qui s\'élance et remonte à son foyer lointain : Un peu de terre en hâte, une pierre qu\'on scelle, Et tout est bien éteint.  Et l\'on viendrait serein, à cette heure dernière, Quand des restes humains le souffle a déserté, Devant ces froids débris, devant cette poussière Parler d\'éternité !  L\'éternité ! Quelle est cette étrange menace ? A l\'amant qui gémit, sous son deuil écrase, Pourquoi jeter ce mot qui terrifie et glace Un cœur déjà brisé ?  Quoi ! le ciel, en dépit de la fosse profonde, S\'ouvrirait à l\'objet de mon amour jaloux ? C\'est assez d\'un tombeau, je ne veux pas d\'un monde Se dressant entre nous.  On me r', 'Ville', '2019-04-01 10:17:14', '2019-04-01 10:17:32', 'Terminé', 1, 'CSS', 'Non', 'Non', 'Au courant de l\'amour lorsque je m\'abandonne, Dans le torrent divin quand je plonge enivré, Et presse éperdument sur mon sein qui frissonne Un être idolâtre.  Je sais que je n\'étreins qu\'une forme fragile, Qu\'elle peut à l\'instant se glacer sous ma main, Que ce cœur tout à moi, fait de flamme et d\'argile, Sera cendre demain ;  Qu\'il n\'en sortira rien, rien, pas une étincelle Qui s\'élance et remonte à son foyer lointain : Un peu de terre en hâte, une pierre qu\'on scelle, Et tout est bien éteint.  Et l\'on viendrait serein, à cette heure dernière, Quand des restes humains le souffle a déserté, Devant ces froids débris, devant cette poussière Parler d\'éternité !  L\'éternité ! Quelle est cette étrange menace ? A l\'amant qui gémit, sous son deuil écrase, Pourquoi jeter ce mot qui terrifie et glace Un cœur déjà brisé ?  Quoi ! le ciel, en dépit de la fosse profonde, S\'ouvrirait à l\'objet de mon amour jaloux ? C\'est assez d\'un tombeau, je ne veux pas d\'un monde Se dressant entre nous.  On me r', 3, '2019-04-01 10:18:22'),
(17, 1, 1, 1, 1, 'azertyuiopqsdfghjklm', 'azertyuiopqsdfghjklm', 'tag', '2019-02-04 12:41:37', '2019-02-27 12:41:40', 'en cours', 1, 'blabla', 'blabla', 'blabla', 'blabla', 1, '2019-02-05 12:42:03'),
(18, 1, 2, 1, 2, 'External Project', 'External Project', 'Project', '2019-02-03 10:26:23', '2019-02-28 10:26:25', 'en cours', 0, 'html, css, php, ajax, js', 'Documentation', 'blabla', 'blabla', 1, '2019-02-14 10:27:33');

-- --------------------------------------------------------

--
-- Structure de la table `serveur`
--

DROP TABLE IF EXISTS `serveur`;
CREATE TABLE IF NOT EXISTS `serveur` (
  `idServeur` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) CHARACTER SET utf8 NOT NULL,
  `nom` varchar(20) CHARACTER SET utf8 NOT NULL,
  `typeAcces` varchar(20) CHARACTER SET utf8 NOT NULL,
  `typeCompte` varchar(20) CHARACTER SET utf8 NOT NULL,
  `test` tinyint(1) NOT NULL,
  PRIMARY KEY (`idServeur`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `serveur`
--

INSERT INTO `serveur` (`idServeur`, `ip`, `nom`, `typeAcces`, `typeCompte`, `test`) VALUES
(1, '192.168.20', 'Bleu', 'Distance', 'Login', 0),
(2, '172.16.254.6', 'rpi', 'PMAD', 'Keypass', 1),
(3, '192.168.1.12', 'Argent', 'Distance', 'DAS', 1),
(4, '172.16.254.1', 'Snowflower', 'Distance', 'Password', 0),
(6, '192.168.1.13', 'Silver', 'Distance', 'Password', 1);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `idUtilisateur` int(11) NOT NULL AUTO_INCREMENT,
  `das` varchar(7) CHARACTER SET utf8 NOT NULL,
  `nom` varchar(20) CHARACTER SET utf8 NOT NULL,
  `prenom` varchar(20) CHARACTER SET utf8 NOT NULL,
  `MotDePasse` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`idUtilisateur`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`idUtilisateur`, `das`, `nom`, `prenom`, `MotDePasse`) VALUES
(1, 'A734529', 'Dupont', 'Jean', 'A734529'),
(2, 'A745354', 'Elestou', 'Jeanna', 'A745354'),
(3, 'A742798', 'Nitrouc', 'Leo', 'A742798'),
(4, 'A109135', 'Lafont', 'Chantal', 'toto'),
(7, 'A121284', 'Pan', 'Peter', 'blablabla'),
(5, 'A123456', 'Fortune', 'Sarah', 'A123456');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
