<?php

// header('content-type: text/html; charset=utf-8');

$idCont = $_GET['contact'];
//var_dump($idCont);
// echo json_encode();

//connexion à la base de données
$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';

//requête sql
$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("SELECT * FROM projet WHERE idContact=".$idCont);
$sth->execute();
$resultProjet = $sth->fetchAll();

//récupère les résultats
foreach ($resultProjet as $key=>$value) {
  $idProjet=$value['idProjet'];
  echo"<tr>";
//  echo "<td align='center'><a href='Unprojet?projet=$idProjet' target='_blank'>".$value['nomProjet']."</a></td>";
  echo "<td align='center'><a href='../view/Unprojet?projet=$idProjet' >".$value['nomProjet']."</a></td>";
  echo "<td align='center'>".$value['statut']."</td>";
  echo "</tr>";
}
