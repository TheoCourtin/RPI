<?php
// header('content-type: text/html; charset=utf-8');

$idCont = $_GET['contact'];
//var_dump($idCont);
// echo json_encode($idCont);

//connexion à la base de données
$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';

//requête sql
$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("SELECT * FROM contact where idContact=$idCont");
$sth->execute();
$resultContact = $sth->fetchAll();
//var_dump($resultContact);

foreach ($resultContact as $key=>$value) {
  $idContact = $value['idContact'];
  //Contact externe ou interne Atos
  $GET['das'] = $value['das'];
  $GET['nom'] = $value['nom'];
  $GET['prenom'] = $value['prenom'];
  $GET['fonction'] = $value['fonction'];
  $GET['email'] = $value['email'];
  $GET['telephone'] = $value['telephone'];
}
//echo json_encode($GET['das']);
//lier les projets du contacts
$sth = $dbh->prepare("SELECT * FROM projet WHERE idContact=".$idCont);
$sth->execute();
$resultProjet = $sth->fetchAll();

//récupère les résultats
foreach ($resultProjet as $key=>$value) {
  $GET['idProjet'] = $value['idProjet'];
	$GET['nomProjet'] = $value['nomProjet'];
	$GET['statut'] = $value['statut'];
}
?>
