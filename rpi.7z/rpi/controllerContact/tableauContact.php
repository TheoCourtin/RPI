<?php
// header('content-type: text/html; charset=utf-8');
//connexion à la base de données
$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';

//requête sql
$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("SELECT * FROM contact");
$sth->execute();
$resultContact = $sth->fetchAll();
//var_dump($resultContact);




foreach ($resultContact as $key=>$value){
  $idContact = $value['idContact'];
  echo '<tr>';
  echo "<td align='center'><a href='../view/unContact?contact=$idContact'>".$value['nom'].' '.$value['prenom']."</a></td>";
  echo "<td align='center'>".$value['email']."</td>";
  echo "<td align='center'>". $value['telephone']."</td>";
  echo '</tr>';
}

//Récupérer les projets du contact
/*$sth = $dbh->prepare("SELECT * from projet WHERE idContact='$idContact'");
$sth->execute();
$resultprojetUtilisateur = $sth->fetchAll();*/
//var_dump($resultprojetUtilisateur);
