<?php
// header('contant-type : text/html; charset=utf-8');

$idContact = $_GET['contact']; //vérifier si la variable est correct (int non vide)
// echo json_encode();

//connexion à la base de donnée
$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';

//requête sql
$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));


$req = $dbh-> prepare('UPDATE contact SET das = :das, nom = :nom, prenom = :prenom, fonction = :fonction, email = :email, telephone = :telephone where idContact= :id');
//var_dump($req);
$sth = $req->execute(array(
  ':id' => $idContact,
  ':das'=> $_POST['das'],
  ':nom'=> $_POST['nom'],
  ':prenom' => $_POST['prenom'],
  ':fonction' => $_POST['fonction'],
  ':email' => $_POST['email'],
  ':telephone' => $_POST['telephone']
));
// $rc= $dbh->errorCode();
// var_dump($rc);

header('location:../view/unContact.php?contact='.$idContact);
exit();
?>
