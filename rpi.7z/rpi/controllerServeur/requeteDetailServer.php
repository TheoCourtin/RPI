<?php
// header('contant-type : text/html; charset=utf-8');

$idServeur = $_GET['serveur'];

//connexion à la base de donnée
$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';

//requête sql
$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("SELECT * from serveur where idServeur=$idServeur");
$sth->execute();
$resultServeur = $sth->fetchAll();
//var_dump($result);

//On définie des variables globales
foreach ($resultServeur as $key=>$value) {
	$nom = $value['nom'];
	$ip = $value['ip'];
	$acces = $value['typeAcces'];
	$compte = $value['typeCompte'];
	$test = $value['test'];
}
