<?php
// header('contant-type : text/html; charset=utf-8');

$idServeur = $_GET['serveur']; //vérifier si la variable est correct (int non vide)

$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';

//requête sql
$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("SELECT * from serveur where idServeur=$idServeur");
$sth->execute();
$resultServeur = $sth->fetchAll();
//var_dump($result);

//On définie des variables globales
foreach ($resultServeur as $key=>$value) {
	$GET['nom'] = $value['nom'];
	$GET['ip'] = $value['ip'];
	$GET['typeAcces'] = $value['typeAcces'];
	$GET['typeCompte'] = $value['typeCompte'];
	$GET['test'] = $value['test'];
//Clé étrangère
}
