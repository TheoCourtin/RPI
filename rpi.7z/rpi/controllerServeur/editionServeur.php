<?php
// header('contant-type : text/html; charset=utf-8');

$idServeur = $_GET['serveur'];
//var_dump($idServeur); //vérifier si la variable est correct (int non vide)
// echo json_encode();

//connexion à la base de donnée
$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';

$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));

$req = $dbh-> prepare('UPDATE serveur SET nom = :nom, ip = :ip, typeAcces = :typeAcces, typeCompte = :typeCompte, test = :test where idServeur= :id');
//var_dump($req);
$sth = $req->execute(array(
  ':id' => $idServeur,
  ':nom'=> $_POST['nom'],
  ':ip'=> $_POST['ip'],
  ':typeAcces' => $_POST["acces"],
  ':typeCompte' => $_POST['compte'],
  ':test' => $_POST['test']
));
//var_dump($req);

header('location:../view/unServeur.php?serveur='.$idServeur);
exit();
?>
