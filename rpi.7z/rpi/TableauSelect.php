<?php
//connexion à la base de donnée
$user = 'root';
$password = '';
$serverLink = 'localhost';
$dbName = 'rpi3';

//requête sql
$dbh = new PDO('mysql:host='.$serverLink.';dbname='.$dbName,$user,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
$sth = $dbh->prepare("SELECT idProjet, nomProjet, dateModification FROM projet ORDER BY dateModification DESC LIMIT 10");
$sth->execute();
$result = $sth->fetchAll();
//var_dump($result);

//tableau ou est stocké le resultat de la requête
  foreach ($result as $key=>$value){
        $idProjet = $value['idProjet'];
        echo '<tr>';
        echo "<td align='center'><a href='Unprojet.php?projet=$idProjet'>".$value['nomProjet'].'</a></td>';
        echo "<td align='center'>".$value['dateModification']."</td>";
        echo '</tr>';
    }
