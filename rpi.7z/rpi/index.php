<?php
//Appel de la connexion
require_once('model/connexion.class.php');
require_once('controller/traduction.php');
?>
<!DOCTYPE html>

<!--Encodage de la page-->
<meta http-equiv="content-type" content="text/html" charset="utf-8">
<!-- Langue par défaut -->
<html lang="en-US">

<!--Extension jQuery-->
<script type='text/javascript' src='extension/jquery-3.3.1.min.js'></script>
<!--Appel du Ajax-->
<script type='text/javascript' src="loginaj.js"></script>
<!--Extension Bootstrap--->
<link rel="stylesheet" href="extension/bootstrap/css/bootstrap.min.css">
<script src="extension/bootstrap/js/bootstrap.min.js"></script>
<!--Ajout du CSS--->
<link rel="stylesheet" href="view/css/default.css">

<head>
  <title>
    <?php
    	echo $langue == "fr" ? connexionFR : connexionEN;
	?>
  </title>
  <?php include('view/menuIndex.php');?>

  </br>
  </br>
</head>

<body>
    <!--formulaire-->
    <div class="container" id="login_form">

		<form class="form-horizontal block-center" role="form" id="login" action="" method="POST">

      <div class="login-body login-night" style="margin:auto;">

        <h2 class="text-center">
          <?php
          	echo $langue == "fr" ? connexionFR : connexionEN;
		  ?>
        </h2>

        <div class="input-group" style="margin:auto"></br>
          <label class="col-xs-2 control-label"><img src="img/login.png"></label>
          <div class="col-xs-10">
			       <input type="das" class="form-control" name="das" placeholder="DAS" id="inputdas" />
           </div>
         </div>

           <div class="input-group" style="margin:auto"></br>
             <label class="col-xs-2 control-label"><img src="img/cadenas.png"></label>
             <div class="col-sm-10">
               <input type="password" class="form-control" name="password" placeholder="<?php	echo $langue == "fr" ? motDePasseFR : motDePasseEN;?>" id="inputpass" />
             </div>
           </div>

           <div class="text-center">
           </br>
          

			</a>
          </br>
          </br>

          <div class "col-xs-12 text-center">
			     <input type="submit" class="btn btn-muted btn-lg" style="margin:auto;" value="<?php 	echo $langue == "fr" ? validerFR : validerEN ?>"/></br></br>
			<!-- This is the div where AJAX will send the response -->
			       <div class="alert_content"></div>
           </div>
		</form>

	</div>
    <!--navbar fixé en bas avec les logos-->

</body>
</html>
