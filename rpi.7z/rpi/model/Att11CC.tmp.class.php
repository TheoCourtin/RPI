<!-- <?php

// $obj_ldap = new auth_ldap('das', 'pwd_das');
// $autorisation = $obj_ldap->get_connexion();



/**
 * Class d'authentification au site
 * via le serveur ldap
 *
 */

 
 class auth_ldap extends User {
  private $_das,
		  $_pwd_das,
		  $_cnx_ldap,
		  $_a_user;

  function __construct($das, $pwd_das) {
    $this->set_das($das);
    $this->set_pwd_das($pwd_das);
    parent::__construct($das, $pwd_das);
  }

  /**
   * Setter Login
   * @param $das
   */
  public function set_das($das) {
    $this->_das = $das;
  }

  /**
   * Setter Password
   * @param $pwd_das
   */
  public function set_pwd_das($pwd_das) {
    $this->_pwd_das = $pwd_das;
  }

  /** Verification acces utilisateur a partir du login / passwd
   *  Si login / passwd reconnus sur le serveur LDAP -> OK
   */
  public function get_connexion() {
    $this->_cnx_ldap = $this->get_connexion_ldap();
    if ($this->_cnx_ldap && $this->_das && $this->_pwd_das) {
      if ($this->match_login_password()) {
        return true;
      }
    }
    return false;
  }

  /**
   *
   */
  private function get_connexion_ldap() {
    // Connexion au serveur
    // --------------------
    $ldap_connect = ldap_connect("ldaps://160.92.209.37", "636");
    if ($ldap_connect) {
      // On modifie le timeout (secondes)
      // -------------------------------
      ldap_set_option($ldap_connect, LDAP_OPT_TIMELIMIT, 20);
      // On modifie la sizelimit
      // -----------------------
      ldap_set_option($ldap_connect, LDAP_OPT_SIZELIMIT, 50);
      // Login LDAP
      // ----------
      if (ldap_bind($ldap_connect, "uid=SV000086,ou=svi,ou=ai,ou=Identities,dc=myOrg", "2SMLd4pK3yCyr1l01!")) {
        return $ldap_connect;
      } else {
        return false;
      }
    } else {
      return false;
    }
    return;
  }

  /**
   * Fait un bind LDAP du DN (issu du login) et du passwd
   * afin de voir si ceux-ci correspondent
   * @return bool Retourne true si bind ok
   */
  public function match_login_password() {
    if($this->_cnx_ldap) {
      $ldap_search = ldap_search($this->_cnx_ldap, "ou=dpi,ou=pi,ou=ai,ou=Identities,dc=myOrg", "(uid=".$this->_das.")", array("dn"));
      $ldap_result = ldap_get_entries($this->_cnx_ldap, $ldap_search);

      if($ldap_result['count'] == 0) {
        return false;
      }
      else {
        $ldap_testbind = @ldap_bind($this->_cnx_ldap, $ldap_result[0]['dn'], $this->_pwd_das);
        if($ldap_testbind) {
          return true;
        } else {
          return false;
        }
      }
    }
  }

  // -----------------
  // --- FIN CLASS ---
  // -----------------
} -->
