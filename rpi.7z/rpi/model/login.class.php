<?php
// we call our file with MySQL connection
require_once('model/connexion.class.php');
// create a new Object


class User{
	private $_das;
	private $_password;

//constructeur

	function __construct($das, $password)
	{
		$this->set_das($das);
		$this->set_password($password);
	}


	//accesseurs
	public function set_das($das) {
		$this->_das = $das;
	}
	public function get_das() {
		return $this->_das;
	}

	public function set_password($password) {
		$this->_password = $password;
	}

	// filter the information from Login form.
	function filter($str){
		//convert case to lower
		$str = strtolower($str);
		//remove special characters
		$str = preg_replace('/[^a-zA-Z0-9]/i',' ', $str);
		//remove white space characters from both side
		$str = trim($str);
		return $str;
	}

	// the function for checking date
	function check_user($das,$password){

			$db = new Connection;
			$das = $this -> filter($das);
			$user = $db -> prepare("SELECT idUtilisateur FROM utilisateur WHERE das=:das");
			$user -> execute(array(
				'das' => $das
			));
			if($user -> rowCount() > 0){
				return true;
			}
			else {
				return false;
			}
			return null;
		}
	}
