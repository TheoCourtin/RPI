1) Installer Wampserver version : 3.1.3(64 bit) ou 3.0.6 (32 bit)  
Lancer Wamp

2) Copier le dossier rpi dans le dossier www du dossier wamp (c:\wamp\www\django_projects)

Ouvrir la console phpmyadmin (localhost/phpmyadmin/)
   cr�er une base nomm�e rpi3
   importer le fichier rpi3sql qui est dans wamp\www\rpi\bdd


3) Sur le navigateur, taper l'addresse : localhost/rpi

Compte principal�:

Das�: A734529 
Mot de passe�: A734529 


